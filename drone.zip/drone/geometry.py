"""Room geometry for a 200 cm Tello cage.

The origin is a floor corner. X increases to the right, Y increases forward,
and Z increases up. All distances are centimetres.

Camera yaw increases clockwise:
0 faces +Y, 90 faces +X, 180 faces -Y, and 270 faces -X.

The flight window starts at START_CM. That pose is editable and is not read
from a mission pad.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

CAGE_CM = 200.0
# Body size: right, forward, up. The centre stays inside so the whole
# aircraft, at any yaw, remains in the cage.
BODY_CM = (18.0, 18.0, 5.0)
FENCE_BUFFER_CM = 10.0
FENCE_PUSH = 30

# Older pad-centre notes kept for the coordinate check below. Flight does not read them.
PADS_CM: dict[int, tuple[float, float]] = {
    1: (55.0, 55.0),
    2: (145.0, 55.0),
    3: (55.0, 145.0),
    4: (145.0, 145.0),
}
START_CM = (55.0, 55.0, 82.0)
START_YAW_DEG = 90.0

# Tello pad-frame unit vectors in (right, forward). Rocket is pad +X.
PAD_X_IN_ROOM = (0.0, 1.0)
PAD_Y_IN_ROOM = (-1.0, 0.0)


def wrap_360(angle: float) -> float:
    """Degrees folded into [0, 360)."""
    return float(angle) % 360.0


def yaw_name(angle: float) -> str:
    """Nearest room axis for a camera heading."""
    shown = wrap_360(angle)
    if shown < 45.0 or shown >= 315.0:
        return "+Y"
    if shown < 135.0:
        return "+X"
    if shown < 225.0:
        return "-Y"
    return "-X"


def camera_yaw_from_pad(pad_yaw_deg: float) -> float:
    """Camera heading from mission-pad ``mpry`` yaw.

    Pad yaw is clockwise from the rocket. The rockets point toward pad 3,
    and room yaw uses that same clockwise sense, so the angles match.
    """
    return wrap_360(float(pad_yaw_deg))


def parse_pad_yaw(mpry: object) -> float | None:
    """Yaw component of a Tello ``mpry`` value, or None when it is absent."""
    if not isinstance(mpry, str):
        return None
    parts = [part.strip() for part in mpry.split(",")]
    if len(parts) < 3:
        return None
    try:
        return float(parts[2])
    except ValueError:
        return None


def world_from_pad(
    pad_id: int,
    tello_x: float,
    tello_y: float,
    tello_z: float,
) -> tuple[float, float, float] | None:
    """Room position of the aircraft from one downward mission pad.

    ``tello_x`` is centimetres along the rocket and ``tello_y`` is centimetres
    to the rocket's left. ``tello_z`` is height above the pad.
    """
    centre = PADS_CM.get(pad_id)
    if centre is None:
        return None
    pad_x, pad_y = centre
    right = pad_x + tello_x * PAD_X_IN_ROOM[0] + tello_y * PAD_Y_IN_ROOM[0]
    forward = pad_y + tello_x * PAD_X_IN_ROOM[1] + tello_y * PAD_Y_IN_ROOM[1]
    return (right, forward, float(tello_z))


def body_margin_xy() -> float:
    """Half-diagonal of the footprint, so a yawed body still clears the wall."""
    return math.hypot(BODY_CM[0] / 2.0, BODY_CM[1] / 2.0)


def flyable_bounds(
    cage_cm: tuple[float, float, float] = (CAGE_CM, CAGE_CM, CAGE_CM),
) -> tuple[tuple[float, float, float], tuple[float, float, float]]:
    """Lowest and highest centre position whose body stays inside the cage.

    ``cage_cm`` is the field size: X right, Y forward, Z up.
    """
    margin_xy = body_margin_xy()
    margin_z = BODY_CM[2] / 2.0
    low = (margin_xy, margin_xy, margin_z)
    high = (
        float(cage_cm[0]) - margin_xy,
        float(cage_cm[1]) - margin_xy,
        float(cage_cm[2]) - margin_z,
    )
    return low, high


def body_to_world(left_right: float, forward: float, yaw_deg: float) -> tuple[float, float]:
    """Room velocity from a body stick. Positive left/right is to the aircraft's right."""
    yaw = math.radians(yaw_deg)
    cosine, sine = math.cos(yaw), math.sin(yaw)
    world_x = left_right * cosine + forward * sine
    world_y = -left_right * sine + forward * cosine
    return (world_x, world_y)


def world_to_body(world_x: float, world_y: float, yaw_deg: float) -> tuple[float, float]:
    """Body stick that produces a room velocity."""
    yaw = math.radians(yaw_deg)
    cosine, sine = math.cos(yaw), math.sin(yaw)
    left_right = world_x * cosine - world_y * sine
    forward = world_x * sine + world_y * cosine
    return (left_right, forward)


def _hold_axis(position: float, low: float, high: float, rate: float) -> tuple[float, bool]:
    """Drop a rate that would cross a limit, and push back when already outside."""
    if position > high:
        return (min(rate, -FENCE_PUSH), True)
    if position >= high - FENCE_BUFFER_CM and rate > 0:
        return (0.0, True)
    if position < low:
        return (max(rate, FENCE_PUSH), True)
    if position <= low + FENCE_BUFFER_CM and rate < 0:
        return (0.0, True)
    return (rate, False)


def _clamp_int(value: float) -> int:
    return max(-100, min(100, int(round(value))))


def shortest_turn(yaw_deg: float, target_deg: float = 0.0) -> tuple[str, int] | None:
    """Shortest Tello rotation toward a room heading.

    Room yaw grows clockwise. The result is ``("cw", degrees)`` or
    ``("ccw", degrees)``. None means the nose is already on the target.
    """
    error = (float(target_deg) - float(yaw_deg) + 180.0) % 360.0 - 180.0
    if error <= -180.0:
        error = 180.0
    degrees = int(round(error))
    if degrees == 0 or abs(degrees) >= 360:
        return None
    if degrees > 0:
        return ("cw", min(360, degrees))
    return ("ccw", min(360, -degrees))


def x_axis_heading(delta_x: float) -> float:
    """Room yaw whose nose is along X. 90 faces +X. 270 faces -X.

    A positive room X change faces +X, so that part of the move is forward.
    """
    return 90.0 if float(delta_x) >= 0.0 else 270.0


@dataclass(frozen=True)
class AxisScale:
    """Actual centimetres traveled for each 100 cm of that body direction.

    Forward and back are the nose axis. Left and right are the body side
    axis. Up and down are vertical. 100 leaves the reading unchanged.
    """

    forward: float = 100.0
    back: float = 100.0
    left: float = 100.0
    right: float = 100.0
    up: float = 100.0
    down: float = 100.0


def _ratio(actual_per_100: float) -> float:
    if actual_per_100 <= 0:
        raise ValueError("A correction has to be greater than 0.")
    return float(actual_per_100) / 100.0


def scale_body_speed(
    right_cm_s: float,
    forward_cm_s: float,
    scale: AxisScale,
) -> tuple[float, float]:
    """Apply a separate correction to right, left, forward, and back speed."""
    right_ratio = _ratio(scale.right if right_cm_s >= 0 else scale.left)
    forward_ratio = _ratio(scale.forward if forward_cm_s >= 0 else scale.back)
    return (right_cm_s * right_ratio, forward_cm_s * forward_ratio)


def scale_vertical_cm(up_cm: float, scale: AxisScale) -> float:
    """Apply the up correction or the down correction to a height change."""
    ratio = _ratio(scale.up if up_cm >= 0 else scale.down)
    return up_cm * ratio


def command_body_cm(
    forward_cm: float,
    right_cm: float,
    up_cm: float,
    scale: AxisScale,
) -> tuple[float, float, float]:
    """Commanded body move that yields the desired actual move.

    If forward only covers 80 cm of a 100 cm command, a 80 cm trip commands 100.
    """
    def command(distance: float, actual_per_100: float) -> float:
        return distance * (100.0 / float(actual_per_100))

    forward = command(forward_cm, scale.forward if forward_cm >= 0 else scale.back)
    right = command(right_cm, scale.right if right_cm >= 0 else scale.left)
    up = command(up_cm, scale.up if up_cm >= 0 else scale.down)
    return (forward, right, up)


def body_direction_names(right_cm: float, forward_cm: float) -> tuple[str, ...]:
    """Body directions with a real share of a horizontal move."""
    names: list[str] = []
    if abs(forward_cm) >= 1.0:
        names.append("forward" if forward_cm > 0 else "back")
    if abs(right_cm) >= 1.0:
        names.append("right" if right_cm > 0 else "left")
    return tuple(names)


def scale_from_measurement(
    scale: AxisScale,
    names: tuple[str, ...],
    desired_cm: float,
    actual_cm: float,
) -> AxisScale:
    """Update corrections from a commanded move and the distance it really covered.

    The stored number stays 'actual centimetres per 100 commanded centimetres'.
    A later try that really covers the requested distance leaves the number as it is.
    """
    if abs(desired_cm) < 1.0:
        raise ValueError("Enter how far the move was supposed to go.")
    if abs(actual_cm) < 1.0:
        raise ValueError("Enter how far the aircraft really moved.")
    if not names:
        raise ValueError("That move is too small to correct.")
    factor = abs(float(actual_cm)) / abs(float(desired_cm))
    values = {name: float(getattr(scale, name)) for name in ("forward", "back", "left", "right", "up", "down")}
    for name in names:
        updated = values[name] * factor
        if updated <= 0 or updated > 500:
            raise ValueError(f"{name.capitalize()} correction has to stay between 0 and 500.")
        values[name] = updated
    return AxisScale(**values)


def tello_go_body(
    forward_cm: float,
    right_cm: float,
    up_cm: float,
) -> tuple[int, int, int] | None:
    """Tello ``go`` from body axes: x forward, y left, z up.

    None means every axis is under 20 cm.
    """
    if max(abs(forward_cm), abs(right_cm), abs(up_cm)) < 20.0:
        return None
    values = [
        max(-500, min(500, int(round(forward_cm)))),
        max(-500, min(500, int(round(-right_cm)))),
        max(-500, min(500, int(round(up_cm)))),
    ]
    if all(abs(value) < 20 for value in values):
        return None
    return (values[0], values[1], values[2])


def tello_go(
    right_cm: float,
    forward_cm: float,
    up_cm: float,
    yaw_deg: float,
) -> tuple[int, int, int] | None:
    """Tello ``go`` distances for a room move: x forward, y left, z up.

    None means the move is under 20 cm, which the aircraft rejects.
    """
    if math.hypot(right_cm, forward_cm) < 20.0 and abs(up_cm) < 20.0:
        return None
    body_right, body_forward = world_to_body(right_cm, forward_cm, yaw_deg)
    axes = [body_forward, -body_right, up_cm]
    peak = max(abs(value) for value in axes)
    if peak < 20.0:
        axes = [value * (20.0 / peak) for value in axes]
    values = [max(-500, min(500, int(round(value)))) for value in axes]
    if all(abs(value) < 20 for value in values):
        index = max(range(3), key=lambda i: abs(axes[i]))
        values[index] = 20 if axes[index] >= 0 else -20
    return (values[0], values[1], values[2])


def fence_rc(
    left_right: int,
    forward: int,
    up_down: int,
    yaw_deg: float,
    position_cm: tuple[float, float, float],
    bounds: tuple[tuple[float, float, float], tuple[float, float, float]],
) -> tuple[int, int, int, bool]:
    """Stick command that cannot carry the body out of the cage.

    Returns left/right, forward, up/down, and whether a limit held the stick.
    """
    low, high = bounds
    world_x, world_y = body_to_world(left_right, forward, yaw_deg)
    world_x, held_x = _hold_axis(position_cm[0], low[0], high[0], world_x)
    world_y, held_y = _hold_axis(position_cm[1], low[1], high[1], world_y)
    up_down_f, held_z = _hold_axis(position_cm[2], low[2], high[2], float(up_down))
    body_right, body_forward = world_to_body(world_x, world_y, yaw_deg)
    return (
        _clamp_int(body_right),
        _clamp_int(body_forward),
        _clamp_int(up_down_f),
        held_x or held_y or held_z,
    )


def _check() -> None:
    centre = world_from_pad(1, 0, 0, 40)
    assert centre == (55.0, 55.0, 40.0)
    # 10 cm along the rocket is 10 cm forward. 10 cm to the rocket's left is -X.
    offset = world_from_pad(1, 10, 10, 40)
    assert offset == (45.0, 65.0, 40.0)
    assert world_from_pad(9, 0, 0, 0) is None

    assert camera_yaw_from_pad(0) == 0.0
    assert camera_yaw_from_pad(90) == 90.0
    assert abs(camera_yaw_from_pad(-90) - 270.0) < 1e-9
    assert camera_yaw_from_pad(180) == 180.0
    assert parse_pad_yaw("1,2,-90") == -90.0
    assert parse_pad_yaw("0") is None

    assert yaw_name(0) == "+Y"
    assert yaw_name(90) == "+X"
    assert yaw_name(180) == "-Y"
    assert yaw_name(270) == "-X"

    # Yaw 90 faces +X. Forward motion increases X.
    right_x, right_y = body_to_world(0, 10, 90)
    assert right_x > 9 and abs(right_y) < 1e-6
    left_x, left_y = body_to_world(0, 10, 270)
    assert left_x < -9 and abs(left_y) < 1e-6
    hover_x, hover_y = body_to_world(0, 10, 0)
    assert abs(hover_x) < 1e-6 and hover_y > 9

    for yaw in (0, 37, 90, 180, 270, 359):
        back_x, back_y = world_to_body(*body_to_world(12, -7, yaw), yaw)
        assert abs(back_x - 12) < 1e-6
        assert abs(back_y - (-7)) < 1e-6

    low, high = flyable_bounds()
    wide_low, wide_high = flyable_bounds((400.0, 200.0, 150.0))
    assert abs(wide_high[0] - (400.0 - body_margin_xy())) < 1e-6
    assert abs(wide_high[1] - high[1]) < 1e-6
    assert abs(wide_low[2] - low[2]) < 1e-6
    held = fence_rc(40, 0, 0, 0, (high[0] - 1, 100, 100), (low, high))
    assert held[0] == 0 and held[3]
    free = fence_rc(0, 40, 10, 0, (100, 100, 100), (low, high))
    assert free == (0, 40, 10, False)
    outside = fence_rc(0, 0, 0, 0, (high[0] + 5, 100, 100), (low, high))
    assert outside[0] < 0 and outside[3]
    ceiling = fence_rc(0, 0, 20, 0, (100, 100, high[2] + 1), (low, high))
    assert ceiling[2] < 0 and ceiling[3]

    # Facing forward, a move to the right is Tello y = -right (y positive is left).
    assert tello_go(50, 0, 0, 0) == (0, -50, 0)
    assert tello_go(0, 50, 0, 0) == (50, 0, 0)
    assert tello_go(50, 0, 0, 90) == (50, 0, 0)
    assert x_axis_heading(-95) == 270.0
    assert x_axis_heading(10) == 90.0
    # From (150, 150) toward (55, 55), facing -X makes the X change a forward move.
    assert tello_go(-95, -95, 0, 270)[0] > 0
    assert tello_go(-95, -95, 0, 90)[0] < 0
    assert tello_go(10, 10, 0, 0) is None
    assert shortest_turn(90, 0) == ("ccw", 90)
    assert shortest_turn(0, 90) == ("cw", 90)
    assert shortest_turn(350, 0) == ("cw", 10)
    assert shortest_turn(0, 0) is None

    even = AxisScale()
    assert scale_body_speed(10, -10, even) == (10, -10)
    short = AxisScale(forward=80, back=50, left=120, right=100, up=90, down=110)
    right_speed, forward_speed = scale_body_speed(-10, 10, short)
    assert abs(right_speed - (-12)) < 1e-9
    assert abs(forward_speed - 8) < 1e-9
    assert abs(scale_vertical_cm(-10, short) - (-11)) < 1e-9
    commanded = command_body_cm(80, -120, 90, short)
    assert abs(commanded[0] - 100) < 1e-9
    assert abs(commanded[1] - (-100)) < 1e-9
    assert abs(commanded[2] - 100) < 1e-9
    assert tello_go_body(100, -50, 0) == (100, 50, 0)
    assert tello_go_body(10, 10, 0) is None
    assert body_direction_names(*world_to_body(100, 0, 90)) == ("forward",)
    assert body_direction_names(*world_to_body(-100, 0, 90)) == ("back",)
    assert body_direction_names(*world_to_body(0, 100, 90)) == ("left",)
    assert body_direction_names(*world_to_body(0, -100, 90)) == ("right",)
    measured = scale_from_measurement(AxisScale(), ("forward",), 100, 80)
    assert measured.forward == 80 and measured.back == 100
    assert scale_from_measurement(measured, ("forward",), 100, 100).forward == 80


if __name__ == "__main__":
    _check()
    print("geometry ok")
