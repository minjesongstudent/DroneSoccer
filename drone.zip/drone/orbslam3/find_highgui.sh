#!/bin/bash
grep -R -n -E 'imshow|waitKey|namedWindow|highgui' "$HOME/orbslam3-build/ORB_SLAM3/src" "$HOME/orbslam3-build/ORB_SLAM3/include" || true
