#!/bin/bash
set -euo pipefail
ROOT="$HOME/orbslam3-build"
mkdir -p "$ROOT/debs" "$ROOT/sysroot" "$ROOT/local/lib"
cd "$ROOT"
if [ ! -d ORB_SLAM3/.git ]; then
  git clone --depth 1 https://github.com/UZ-SLAMLab/ORB_SLAM3.git ORB_SLAM3
fi
if [ ! -d Pangolin/.git ]; then
  git clone --depth 1 --branch v0.6 https://github.com/stevenlovegrove/Pangolin.git Pangolin
fi
if [ ! -e "$ROOT/local/lib/libboost_serialization.so" ]; then
  ln -s /usr/lib/x86_64-linux-gnu/libboost_serialization.so.1.83.0 "$ROOT/local/lib/libboost_serialization.so"
fi
cd "$ROOT/debs"
if ! find "$ROOT/sysroot/usr/include" -name 'gl.h' | grep -q .; then
  apt-get download libglew-dev libglew2.2 libgl1-mesa-dev libgl-dev libglx-dev libegl1-mesa-dev libglu1-mesa-dev mesa-common-dev libx11-dev libxext-dev libxi-dev libxrandr-dev libxinerama-dev libxcursor-dev libxfixes-dev libxxf86vm-dev libopengl-dev libglvnd-dev
  for deb in *.deb; do
    dpkg-deb -x "$deb" "$ROOT/sysroot"
  done
fi
echo "sources ready"
