"""Tello window: forward camera, room position, and the field fence.

The estimate starts at (55, 55, 82) cm. Drop an ORB-SLAM3 YAML file so the
forward camera can update X and Y. Manual buttons and keys fly the aircraft.
"""

from __future__ import annotations

import json
import math
import threading
import tkinter as tk
import zipfile
from pathlib import Path
from tkinter import filedialog, ttk

from PIL import Image, ImageTk

try:
    from tkinterdnd2 import DND_FILES, TkinterDnD
except ImportError:
    DND_FILES = None
    TkinterDnD = None

from geometry import CAGE_CM, START_CM, START_YAW_DEG, flyable_bounds, wrap_360, yaw_name
from orb_track import DEFAULT_YAML_DIR, newest_yaml
from tello_flight import Snapshot, TelloFlight
from vision import mark_view

BG = "#121418"
PANEL = "#1c2128"
VIDEO_BG = "#0e1116"
TEXT = "#f2f4f8"
MUTED = "#9aa3b2"
FIELD = "#0e1116"
BORDER = "#3a4250"
OK = "#2f6f4e"
DANGER = "#8c2f39"
HOLD = "#c4a35a"
ACCENT = "#1d4ed8"
BUTTON = "#2e3646"

MAP_SIZE = 200


class FlightWindow:
    def __init__(self) -> None:
        self.flight = TelloFlight()
        self._photo = None
        self._keys: set[str] = set()
        self._mouse = {"lr": 0, "fb": 0, "ud": 0, "yaw": 0}
        self._closing = False
        self._alive = True

        self.root = TkinterDnD.Tk() if TkinterDnD is not None else tk.Tk()
        self.root.title("Tello")
        self.root.configure(bg=BG)
        self._style = ttk.Style(self.root)
        self._style.theme_use("clam")
        self._button_styles: set[str] = set()
        self.root.minsize(1100, 720)
        self.root.geometry("1280x800")

        self._build()
        try:
            self.root.state("zoomed")
        except tk.TclError:
            pass
        self.root.bind("<KeyPress>", self._key_down)
        self.root.bind("<KeyRelease>", self._key_up)
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self.root.after(30, self._tick)

    def run(self) -> None:
        self.root.mainloop()

    def _build(self) -> None:
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(1, weight=1)

        toolbar = tk.Frame(self.root, bg=BG)
        toolbar.grid(row=0, column=0, sticky="ew", padx=12, pady=(10, 4))
        self.ip = tk.StringVar(value="192.168.10.1")
        ip_entry = tk.Entry(
            toolbar,
            textvariable=self.ip,
            bg=FIELD,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            font=("Segoe UI", 11),
            width=16,
        )
        ip_entry.pack(side="left", ipady=4)
        self.connect_button = self._button(toolbar, "Connect", self._connect, OK)
        self.connect_button.pack(side="left", padx=(8, 12))
        self.emergency_button = self._button(toolbar, "Emergency", self._emergency, DANGER)
        self.emergency_button.pack(side="right")
        self.land_button = self._button(toolbar, "Land", self._land, DANGER)
        self.land_button.pack(side="right", padx=8)
        self.takeoff_button = self._button(toolbar, "Take off", self._takeoff, OK)
        self.takeoff_button.pack(side="right")
        self.status = tk.Label(
            toolbar,
            text="",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 10),
            anchor="w",
            justify="left",
        )
        self.status.pack(side="left", fill="x", expand=True)

        scroller = tk.Frame(self.root, bg=BG)
        scroller.grid(row=1, column=0, sticky="nsew")
        self._scroll = tk.Canvas(scroller, bg=BG, highlightthickness=0, bd=0)
        bar = tk.Scrollbar(
            scroller,
            orient="vertical",
            command=self._scroll.yview,
            bg=PANEL,
            troughcolor=FIELD,
            activebackground=BORDER,
            highlightthickness=0,
            bd=0,
        )
        self._scroll.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        self._scroll.pack(side="left", fill="both", expand=True)
        self._build_logs()
        page = tk.Frame(self._scroll, bg=BG)
        self._page = page
        self._scroll_window = self._scroll.create_window((0, 0), window=page, anchor="nw")
        self._fitting = False
        page.bind("<Configure>", self._scroll_region)
        self._scroll.bind("<Configure>", self._scroll_width)
        self.root.bind_all("<MouseWheel>", self._on_mousewheel)
        page.columnconfigure(0, weight=1)
        page.columnconfigure(1, weight=0)
        page.rowconfigure(0, weight=1, minsize=320)

        video_wrap = tk.Frame(page, bg=VIDEO_BG)
        video_wrap.grid(row=0, column=0, sticky="nsew", padx=(12, 8), pady=4)
        self.video = tk.Label(
            video_wrap,
            text="Camera is off.\nConnect to the Tello Wi-Fi, then press Connect.",
            bg=VIDEO_BG,
            fg=MUTED,
            font=("Segoe UI", 14),
            justify="center",
        )
        self.video.pack(fill="both", expand=True)

        side = tk.Frame(page, bg=BG)
        side.grid(row=0, column=1, sticky="nsew", padx=(4, 12), pady=4)

        yaml_box = tk.Frame(side, bg=FIELD, highlightbackground=BORDER, highlightthickness=1)
        yaml_box.pack(fill="x", pady=(0, 8))
        self.yaml_drop = tk.Label(
            yaml_box,
            text="Drop an ORB-SLAM3 YAML here",
            bg=FIELD,
            fg=MUTED,
            font=("Segoe UI", 12),
            pady=18,
        )
        self.yaml_drop.pack(fill="x", padx=8, pady=(8, 0))
        yaml_row = tk.Frame(yaml_box, bg=FIELD)
        yaml_row.pack(fill="x", padx=8, pady=8)
        self._button(yaml_row, "Browse", self._browse_yaml, ACCENT).pack(side="left")
        self.yaml_file = tk.Label(
            yaml_row,
            text="No file loaded",
            bg=FIELD,
            fg=TEXT,
            font=("Segoe UI", 10),
            anchor="w",
        )
        self.yaml_file.pack(side="left", fill="x", expand=True, padx=(8, 0))
        slam_row = tk.Frame(yaml_box, bg=FIELD)
        slam_row.pack(fill="x", padx=8, pady=(0, 4))
        self.slam3_var = tk.IntVar(value=1)
        tk.Checkbutton(
            slam_row,
            text="ORB-SLAM3",
            variable=self.slam3_var,
            command=self._toggle_slam3,
            bg=FIELD,
            fg=TEXT,
            selectcolor=PANEL,
            activebackground=FIELD,
            activeforeground=TEXT,
            font=("Segoe UI", 10),
        ).pack(side="left")
        tk.Label(slam_row, text="cm/unit", bg=FIELD, fg=MUTED, font=("Segoe UI", 9)).pack(side="left", padx=(12, 4))
        self.slam_scale_var = tk.StringVar(value="100")
        scale_box = self._number_entry(slam_row, self.slam_scale_var, self._apply_slam_scale, width=5, font_size=10)
        scale_box.pack(side="left")
        tk.Label(
            yaml_box,
            text=str(DEFAULT_YAML_DIR),
            bg=FIELD,
            fg=MUTED,
            font=("Segoe UI", 8),
            anchor="w",
            justify="left",
            wraplength=440,
        ).pack(fill="x", padx=8, pady=(0, 8))
        if DND_FILES is not None:
            self.yaml_drop.drop_target_register(DND_FILES)
            self.yaml_drop.dnd_bind("<<Drop>>", self._files_dropped)
            self.yaml_drop.dnd_bind("<<DragEnter>>", self._yaml_enter)
            self.yaml_drop.dnd_bind("<<DragLeave>>", self._yaml_leave)

        policy_box = tk.Frame(side, bg=FIELD, highlightbackground=BORDER, highlightthickness=1)
        policy_box.pack(fill="x", pady=(0, 8))
        tk.Label(
            policy_box,
            text="RL policy",
            bg=FIELD,
            fg=TEXT,
            font=("Segoe UI", 10, "bold"),
            anchor="w",
        ).pack(fill="x", padx=8, pady=(8, 0))
        self.policy_drop = tk.Label(
            policy_box,
            text="Drop a policy .zip here",
            bg=FIELD,
            fg=MUTED,
            font=("Segoe UI", 12),
            pady=14,
        )
        self.policy_drop.pack(fill="x", padx=8, pady=(4, 0))
        policy_row = tk.Frame(policy_box, bg=FIELD)
        policy_row.pack(fill="x", padx=8, pady=8)
        self._button(policy_row, "Browse", self._browse_policy, ACCENT).pack(side="left")
        self.policy_file = tk.Label(
            policy_row,
            text="No policy loaded",
            bg=FIELD,
            fg=TEXT,
            font=("Segoe UI", 10),
            anchor="w",
        )
        self.policy_file.pack(side="left", fill="x", expand=True, padx=(8, 0))
        if DND_FILES is not None:
            self.policy_drop.drop_target_register(DND_FILES)
            self.policy_drop.dnd_bind("<<Drop>>", self._files_dropped)
            self.policy_drop.dnd_bind("<<DragEnter>>", self._yaml_enter)
            self.policy_drop.dnd_bind("<<DragLeave>>", self._yaml_leave)
        self._policy_path: Path | None = None

        pose = tk.Frame(side, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        pose.pack(fill="x")
        self.readouts: dict[str, tk.Label] = {}
        for index, (key, title) in enumerate((("x", "X"), ("y", "Y"), ("z", "Z"), ("yaw", "Yaw"))):
            cell = tk.Frame(pose, bg=PANEL)
            cell.grid(row=index // 2, column=index % 2, sticky="ew", padx=10, pady=4)
            pose.columnconfigure(index % 2, weight=1)
            tk.Label(cell, text=title, bg=PANEL, fg=MUTED, font=("Segoe UI", 10), width=4, anchor="w").pack(
                side="left"
            )
            value = tk.Label(cell, text="—", bg=PANEL, fg=TEXT, font=("Segoe UI", 16, "bold"), anchor="w")
            value.pack(side="left", fill="x")
            self.readouts[key] = value
        self.detail = tk.Label(
            pose,
            text="Yaw 0 faces +Y. Yaw 90 faces +X. Drop an ORB-SLAM3 YAML to track X and Y.",
            wraplength=460,
            bg=PANEL,
            fg=MUTED,
            font=("Segoe UI", 9),
            anchor="w",
            justify="left",
        )
        self.detail.grid(row=2, column=0, columnspan=2, sticky="ew", padx=10, pady=(0, 8))

        lower = tk.Frame(side, bg=BG)
        lower.pack(fill="both", expand=True, pady=(8, 0))
        self.map = tk.Canvas(lower, width=MAP_SIZE, height=MAP_SIZE, bg=FIELD, highlightthickness=0)
        self.map.pack(side="left")
        self.z_bar = tk.Canvas(lower, width=22, height=MAP_SIZE, bg=FIELD, highlightthickness=0)
        self.z_bar.pack(side="left", padx=(6, 8))

        manual = tk.LabelFrame(
            lower,
            text="Manual",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        manual.pack(side="left", anchor="n")
        holds = (
            (0, 1, "Forward", "fb", 1),
            (1, 0, "Left", "lr", -1),
            (1, 2, "Right", "lr", 1),
            (2, 1, "Back", "fb", -1),
            (0, 3, "Up", "ud", 1),
            (1, 3, "Down", "ud", -1),
            (2, 0, "Turn L", "yaw", -1),
            (2, 2, "Turn R", "yaw", 1),
        )
        for row, column, label, axis, sign in holds:
            button = self._button(manual, label, lambda: None, BUTTON, compact=True)
            button.configure(command=lambda: None)
            button.grid(row=row, column=column, padx=2, pady=2, sticky="nsew")
            self._bind_hold(button, axis, sign)

        plans = tk.Frame(page, bg=BG)
        plans.grid(row=1, column=0, columnspan=2, sticky="ew", padx=12, pady=(4, 8))
        plans.columnconfigure(0, weight=1, uniform="plans")
        plans.columnconfigure(1, weight=1, uniform="plans")

        save = tk.LabelFrame(
            plans,
            text="Start position",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        save.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        form = tk.Frame(save, bg=BG)
        form.pack(fill="x", padx=8, pady=(4, 2))
        self.pose_vars = {
            "x": tk.StringVar(value=_format_start(START_CM[0])),
            "y": tk.StringVar(value=_format_start(START_CM[1])),
            "z": tk.StringVar(value=_format_start(START_CM[2])),
            "yaw": tk.StringVar(value=_format_start(START_YAW_DEG)),
        }
        for column, (key, title) in enumerate((("x", "X"), ("y", "Y"), ("z", "Z"), ("yaw", "Yaw"))):
            tk.Label(form, text=title, bg=BG, fg=MUTED, font=("Segoe UI", 9)).grid(row=0, column=column, sticky="w")
            box = tk.Entry(
                form,
                textvariable=self.pose_vars[key],
                bg=FIELD,
                fg=TEXT,
                insertbackground=TEXT,
                relief="flat",
                font=("Segoe UI", 12),
                width=8,
            )
            box.grid(row=1, column=column, sticky="w", padx=(0, 10), pady=(0, 4))
            box.bind("<Return>", lambda _event: self._apply())
            self.pose_vars[key + "_entry"] = box  # type: ignore[assignment]
        self.apply_button = self._button(form, "Set start", self._apply, ACCENT)
        self.apply_button.grid(row=1, column=4, padx=(4, 8))
        tk.Label(
            save,
            text=(
                "Centimetres and degrees. Set start places the estimate at these values. "
                "X and Y then follow the forward camera. Height follows the floor sensor from this Z. "
                "Hold Manual or use arrows, W/S, and A/D. A short W or S climbs slowly. "
                "1 takes off and 2 lands. Field size sets the room."
            ),
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 9),
            wraplength=460,
            justify="left",
            anchor="w",
        ).pack(fill="x", padx=8, pady=(0, 8))
        self._load_remembered_files()

        move = tk.LabelFrame(
            plans,
            text="Move to a room position",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        move.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        target = tk.Frame(move, bg=BG)
        target.pack(fill="x", padx=8, pady=(4, 2))
        for column, title in enumerate(("X", "Y", "Z")):
            tk.Label(target, text=title, bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(
                row=0, column=column + 1, sticky="w"
            )
        self.target_vars: list[dict[str, tk.StringVar]] = []
        self.go_buttons: list[ttk.Button] = []
        for index in range(5):
            row = index + 1
            tk.Label(target, text=str(index + 1), bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(
                row=row, column=0, sticky="w", padx=(0, 6)
            )
            fields = {key: tk.StringVar() for key in ("x", "y", "z")}
            if index == 0:
                fields["x"].set("150")
                fields["y"].set("150")
                fields["z"].set("150")
            elif index == 1:
                fields["x"].set(_format_start(START_CM[0]))
                fields["y"].set(_format_start(START_CM[1]))
                fields["z"].set(_format_start(START_CM[2]))
            self.target_vars.append(fields)
            for column, key in enumerate(("x", "y", "z")):
                box = self._number_entry(
                    target, fields[key], lambda i=index: self._go(i), width=5, font_size=9
                )
                box.grid(row=row, column=column + 1, sticky="w", padx=(0, 4), pady=(0, 2))
            go_button = self._button(target, "Go", lambda i=index: self._go(i), ACCENT, compact=True)
            go_button.grid(row=row, column=4, padx=(4, 0))
            go_button.configure(state="disabled")
            self.go_buttons.append(go_button)
        tk.Label(
            move,
            text="Each Go flies to that row inside the field.",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 8),
            anchor="w",
        ).pack(fill="x", padx=8, pady=(0, 6))

        tools = tk.Frame(page, bg=BG)
        tools.grid(row=2, column=0, columnspan=2, sticky="ew", padx=12, pady=(0, 12))

        shift = tk.LabelFrame(
            tools,
            text="Move X or Y",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        shift.grid(row=0, column=0, sticky="nw")
        axes = tk.Frame(shift, bg=BG)
        axes.pack(fill="x", padx=6, pady=(2, 0))
        self.shift_vars = {
            "x": tk.StringVar(),
            "x_actual": tk.StringVar(),
            "y": tk.StringVar(),
            "y_actual": tk.StringVar(),
        }
        self.move_buttons: dict[str, ttk.Button] = {}
        for index, axis in enumerate(("x", "y")):
            column = index * 4
            title = "X move" if axis == "x" else "Y move"
            tk.Label(axes, text=title, bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(
                row=0, column=column, sticky="w"
            )
            move_box = self._number_entry(
                axes, self.shift_vars[axis], lambda a=axis: self._move_axis(a), width=4, font_size=9
            )
            move_box.grid(row=1, column=column, sticky="w", padx=(0, 4), pady=(0, 2))
            move_button = self._button(axes, "Move", lambda a=axis: self._move_axis(a), ACCENT, compact=True)
            move_button.grid(row=1, column=column + 1, padx=(0, 8))
            move_button.configure(state="disabled")
            self.move_buttons[axis] = move_button
            tk.Label(axes, text="Actual", bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(
                row=0, column=column + 2, sticky="w"
            )
            actual_box = self._number_entry(
                axes,
                self.shift_vars[axis + "_actual"],
                lambda a=axis: self._save_axis(a),
                width=4,
                font_size=9,
            )
            actual_box.grid(row=1, column=column + 2, sticky="w", padx=(0, 4), pady=(0, 2))
            save_button = self._button(axes, "Save", lambda a=axis: self._save_axis(a), PANEL, compact=True)
            save_button.grid(row=1, column=column + 3, padx=(0, 10))
        self.correction_label = tk.Label(
            shift,
            text="",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 8),
            wraplength=420,
            justify="left",
            anchor="w",
        )
        self.correction_label.pack(fill="x", padx=6, pady=(0, 6))
        self._paint_corrections()

        field = tk.LabelFrame(
            tools,
            text="Field size",
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        field.grid(row=0, column=1, sticky="nw", padx=(8, 0))
        cage_form = tk.Frame(field, bg=BG)
        cage_form.pack(fill="x", padx=6, pady=(2, 0))
        self.cage_vars = {
            "x": tk.StringVar(value=_format_start(CAGE_CM)),
            "y": tk.StringVar(value=_format_start(CAGE_CM)),
            "z": tk.StringVar(value=_format_start(CAGE_CM)),
        }
        for column, (key, title) in enumerate((("x", "X"), ("y", "Y"), ("z", "Z"))):
            tk.Label(cage_form, text=title, bg=BG, fg=MUTED, font=("Segoe UI", 8)).grid(
                row=0, column=column, sticky="w"
            )
            box = self._number_entry(cage_form, self.cage_vars[key], self._set_field, width=4, font_size=9)
            box.grid(row=1, column=column, sticky="w", padx=(0, 4), pady=(0, 2))
        self._button(cage_form, "Set", self._set_field, ACCENT, compact=True).grid(
            row=1, column=3, padx=(2, 0)
        )
        tk.Label(
            field,
            text="Centimetres. X is right, Y is forward, Z is up. The fence and the map use this room.",
            bg=BG,
            fg=MUTED,
            font=("Segoe UI", 8),
            wraplength=280,
            justify="left",
            anchor="w",
        ).pack(fill="x", padx=6, pady=(0, 6))

    def _build_logs(self) -> None:
        """Error text and the SDK commands that were actually sent."""
        logs = tk.Frame(self.root, bg=BG)
        logs.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 10))
        logs.columnconfigure(0, weight=1, uniform="logs")
        logs.columnconfigure(1, weight=1, uniform="logs")
        logs.rowconfigure(0, weight=1)
        self.output_box = self._log_pane(logs, 0, "Output", "#f3d0d0", self._clear_output)
        self.command_box = self._log_pane(logs, 1, "Commands", TEXT, self._clear_commands)
        self._output_shown = ""
        self._command_shown = ""

    def _log_pane(self, parent: tk.Frame, column: int, title: str, color: str, on_clear) -> tk.Text:
        pane = tk.LabelFrame(
            parent,
            text=title,
            bg=BG,
            fg=TEXT,
            font=("Segoe UI", 10),
            labelanchor="nw",
        )
        pane.grid(row=0, column=column, sticky="nsew", padx=(0 if column == 0 else 6, 6 if column == 0 else 0))
        self._button(pane, "Clear", on_clear, BUTTON, compact=True).pack(anchor="e", padx=6, pady=(2, 0))
        box = tk.Text(
            pane,
            height=7,
            bg=FIELD,
            fg=color,
            insertbackground=TEXT,
            relief="flat",
            font=("Consolas", 10),
            wrap="word",
            highlightthickness=0,
            padx=8,
            pady=4,
        )
        bar = tk.Scrollbar(
            pane,
            orient="vertical",
            command=box.yview,
            bg=PANEL,
            troughcolor=FIELD,
            activebackground=BORDER,
            highlightthickness=0,
            bd=0,
        )
        box.configure(yscrollcommand=bar.set)
        bar.pack(side="right", fill="y")
        box.pack(side="left", fill="both", expand=True)
        box.bind("<Key>", self._log_key)
        return box

    def _log_key(self, event: tk.Event):
        """Let the log be copied, and ignore typing."""
        if event.state & 0x4 and event.keysym.lower() in {"c", "a", "insert"}:
            return None
        return "break"

    def _clear_output(self) -> None:
        self.flight.clear_output()
        self._output_shown = ""
        self.output_box.delete("1.0", "end")

    def _clear_commands(self) -> None:
        self.flight.clear_commands()
        self._command_shown = ""
        self.command_box.delete("1.0", "end")

    def _number_entry(
        self,
        parent: tk.Widget,
        variable: tk.StringVar,
        on_return,
        width: int = 7,
        font_size: int = 12,
    ) -> tk.Entry:
        box = tk.Entry(
            parent,
            textvariable=variable,
            bg=FIELD,
            fg=TEXT,
            insertbackground=TEXT,
            relief="flat",
            font=("Segoe UI", font_size),
            width=width,
        )
        box.bind("<Return>", lambda _event: on_return())
        return box

    def _button(self, parent: tk.Widget, text: str, command, color: str, compact: bool = False) -> ttk.Button:
        """Colored button whose label stays light on the fill, including while disabled."""
        kind = "compact" if compact else "normal"
        style_name = f"Tello.{kind}.{color}.TButton"
        if style_name not in self._button_styles:
            padding = (8, 2) if compact else (12, 6)
            font = ("Segoe UI", 9 if compact else 10)
            self._style.configure(
                style_name,
                background=color,
                foreground="#ffffff",
                bordercolor=color,
                darkcolor=color,
                lightcolor=color,
                borderwidth=0,
                focusthickness=0,
                focuscolor=color,
                padding=padding,
                font=font,
            )
            self._style.map(
                style_name,
                background=[
                    ("disabled", _shade(color, 0.78)),
                    ("pressed", _shade(color, 0.86)),
                    ("active", _shade(color, 1.12)),
                ],
                foreground=[
                    ("disabled", "#ffffff"),
                    ("pressed", "#ffffff"),
                    ("active", "#ffffff"),
                ],
                bordercolor=[
                    ("disabled", _shade(color, 0.78)),
                    ("pressed", _shade(color, 0.86)),
                    ("active", _shade(color, 1.12)),
                ],
                darkcolor=[
                    ("disabled", _shade(color, 0.78)),
                    ("active", _shade(color, 1.12)),
                ],
                lightcolor=[
                    ("disabled", _shade(color, 0.78)),
                    ("active", _shade(color, 1.12)),
                ],
            )
            self._button_styles.add(style_name)
        return ttk.Button(parent, text=text, command=command, style=style_name, cursor="hand2")

    def _connect(self) -> None:
        host = self.ip.get()
        self._run("connect", lambda: self.flight.connect(host))

    def _takeoff(self) -> None:
        self._run("takeoff", self.flight.takeoff)

    def _land(self) -> None:
        self._keys.clear()
        self._mouse = {"lr": 0, "fb": 0, "ud": 0, "yaw": 0}
        self.flight.set_channels(0, 0, 0, 0)
        self._run("land", self.flight.land)

    def _emergency(self) -> None:
        self._keys.clear()
        self._mouse = {"lr": 0, "fb": 0, "ud": 0, "yaw": 0}
        self.flight.set_channels(0, 0, 0, 0)
        self._run("emergency", self.flight.emergency)

    def _run(self, name: str, action) -> None:
        def work() -> None:
            try:
                action()
            except Exception as ex:
                if name == "emergency":
                    return
                text = str(ex)
                if text and text not in self.flight.snapshot().message:
                    self.flight.report(f"{name} failed: {text}")

        threading.Thread(target=work, name=f"tello-{name}", daemon=True).start()

    def _apply(self) -> None:
        try:
            x = float(self.pose_vars["x"].get().strip())
            y = float(self.pose_vars["y"].get().strip())
            z = float(self.pose_vars["z"].get().strip())
            yaw = float(self.pose_vars["yaw"].get().strip())
            self.flight.set_pose(x, y, z, yaw)
            self.video.focus_set()
        except ValueError as ex:
            text = str(ex)
            if "could not convert" in text or "invalid literal" in text:
                text = "Enter X, Y, Z, and yaw as numbers."
            self.flight.report(text)

    def _browse_yaml(self) -> None:
        try:
            DEFAULT_YAML_DIR.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        selected = filedialog.askopenfilename(
            title="ORB-SLAM3 calibration YAML",
            initialdir=str(_remembered_dir("yaml", DEFAULT_YAML_DIR)),
            filetypes=[("ORB-SLAM3 YAML", "*.yaml *.yml"), ("All files", "*.*")],
        )
        if selected:
            self._load_yaml(Path(selected))

    def _browse_policy(self) -> None:
        initial = Path(r"D:\codebymin\classes")
        selected = filedialog.askopenfilename(
            title="RL policy zip",
            initialdir=str(_remembered_dir("policy", initial if initial.is_dir() else Path.home())),
            filetypes=[("RL policy", "*.zip"), ("All files", "*.*")],
        )
        if selected:
            self._load_policy(Path(selected))

    def _load_policy(self, path: Path) -> None:
        if path.suffix.lower() != ".zip" or not path.is_file():
            self.flight.report("Drop an RL policy .zip file.")
            return
        try:
            with zipfile.ZipFile(path) as archive:
                names = set(archive.namelist())
        except (OSError, zipfile.BadZipFile):
            self.flight.report(f"{path.name} is not a readable zip file.")
            return
        if "policy.pth" not in names and "data" not in names:
            self.flight.report(f"{path.name} is not a Stable-Baselines3 policy zip.")
            return
        self._policy_path = path
        self.policy_file.configure(text=path.name)
        _remember_file("policy", path)
        self.flight.note(f"Loaded policy {path.name}.")

    def _yaml_enter(self, event) -> None:
        event.widget.configure(bg="#243044", fg=TEXT)

    def _yaml_leave(self, event) -> None:
        event.widget.configure(bg=FIELD, fg=MUTED)

    def _files_dropped(self, event) -> None:
        self._yaml_leave(event)
        paths = [Path(item) for item in self.root.tk.splitlist(event.data)]
        for path in paths:
            if path.is_dir():
                yaml_file = newest_yaml(path)
                if yaml_file is not None:
                    self._load_yaml(yaml_file)
                    return
                policy_file = _newest_zip(path)
                if policy_file is not None:
                    self._load_policy(policy_file)
                    return
            elif path.is_file() and path.suffix.lower() in {".yaml", ".yml"}:
                self._load_yaml(path)
                return
            elif path.is_file() and path.suffix.lower() == ".zip":
                self._load_policy(path)
                return
        self.flight.report("Drop an ORB-SLAM3 YAML or an RL policy .zip.")

    def _load_remembered_files(self) -> None:
        """Open the last YAML and policy. With no saved YAML, the slot stays empty."""
        saved = _read_last_files()
        yaml_path = _saved_path(saved, "yaml")
        policy_path = _saved_path(saved, "policy")
        if yaml_path is not None and yaml_path.is_file():
            self._load_yaml(yaml_path)
        elif yaml_path is not None:
            self.flight.report(f"Saved calibration is missing: {yaml_path.name}")
        if policy_path is not None and policy_path.is_file():
            self._load_policy(policy_path)
        elif policy_path is not None:
            self.flight.report(f"Saved policy is missing: {policy_path.name}")

    def _load_yaml(self, path: Path) -> None:
        path = Path(path)
        if path.is_file():
            _remember_file("yaml", path)
            self.yaml_file.configure(text=path.name)
        try:
            self.flight.load_calibration(path)
        except ValueError as ex:
            self.flight.report(str(ex))
            return
        if self.slam3_var.get():
            try:
                self.flight.set_slam3(True)
            except ValueError as ex:
                self.slam3_var.set(0)
                self.flight.report(str(ex))

    def _go(self, index: int) -> None:
        self._keys.clear()
        self._mouse = {"lr": 0, "fb": 0, "ud": 0, "yaw": 0}
        self.flight.set_channels(0, 0, 0, 0)
        fields = self.target_vars[index]
        try:
            x = float(fields["x"].get().strip())
            y = float(fields["y"].get().strip())
            z = float(fields["z"].get().strip())
        except ValueError as ex:
            self.flight.report(_number_message(ex, "Enter X, Y, and Z as numbers."))
            return
        self.video.focus_set()
        self._run("go", lambda: self.flight.go_to(x, y, z))

    def _toggle_slam3(self) -> None:
        enabled = bool(self.slam3_var.get())
        if not self._apply_slam_scale():
            self.slam3_var.set(0)
            return
        try:
            self.flight.set_slam3(enabled)
        except ValueError as ex:
            self.slam3_var.set(0)
            self.flight.report(str(ex))
        self.video.focus_set()

    def _apply_slam_scale(self) -> bool:
        try:
            self.flight.set_slam_scale(float(self.slam_scale_var.get().strip()))
        except ValueError as ex:
            self.flight.report(_number_message(ex, "Enter cm/unit as a number."))
            return False
        return True

    def _set_field(self) -> None:
        try:
            x = float(self.cage_vars["x"].get().strip())
            y = float(self.cage_vars["y"].get().strip())
            z = float(self.cage_vars["z"].get().strip())
            self.flight.set_cage(x, y, z)
            self.video.focus_set()
        except ValueError as ex:
            self.flight.report(_number_message(ex, "Enter the field size as numbers."))

    def _move_axis(self, axis: str) -> None:
        self._keys.clear()
        self._mouse = {"lr": 0, "fb": 0, "ud": 0, "yaw": 0}
        self.flight.set_channels(0, 0, 0, 0)
        try:
            distance = float(self.shift_vars[axis].get().strip())
        except ValueError as ex:
            self.flight.report(_number_message(ex, f"Enter the {axis.upper()} move in centimetres."))
            return
        self.video.focus_set()
        self._run("move", lambda: self.flight.move_axis(axis, distance))

    def _save_axis(self, axis: str) -> None:
        try:
            actual = float(self.shift_vars[axis + "_actual"].get().strip())
            self.flight.save_axis_measurement(axis, actual)
            self._paint_corrections()
            self.video.focus_set()
        except ValueError as ex:
            self.flight.report(_number_message(ex, "Enter the actual centimetres as a number."))

    def _bind_hold(self, button: tk.Button, axis: str, sign: int) -> None:
        """Hold the button to send that stick. Releasing it stops the axis."""

        def press(_event: tk.Event) -> None:
            self._mouse[axis] = sign

        def release(_event: tk.Event) -> None:
            if self._mouse.get(axis) == sign:
                self._mouse[axis] = 0

        button.bind("<ButtonPress-1>", press)
        button.bind("<ButtonRelease-1>", release)
        button.bind("<Leave>", release)

    def _typing(self, widget: tk.Widget) -> bool:
        return isinstance(widget, tk.Entry)

    def _key_down(self, event: tk.Event) -> None:
        if self._typing(event.widget):
            return
        if event.keysym == "space":
            self._keys.clear()
            self.flight.set_channels(0, 0, 0, 0)
            return
        if event.keysym == "1":
            if event.keysym not in self._keys:
                self._keys.add(event.keysym)
                self._takeoff()
            return
        if event.keysym == "2":
            if event.keysym not in self._keys:
                self._keys.add(event.keysym)
                self._land()
            return
        self._keys.add(event.keysym)

    def _key_up(self, event: tk.Event) -> None:
        self._keys.discard(event.keysym)

    def _send_keys(self) -> None:
        speed = 35
        forward = left_right = up_down = yaw = 0
        if not self._typing(self.root.focus_get() or self.root):
            keys = {key.lower() if len(key) == 1 else key for key in self._keys}
            forward = (1 if "Up" in keys else 0) - (1 if "Down" in keys else 0)
            left_right = (1 if "Right" in keys else 0) - (1 if "Left" in keys else 0)
            up_down = (1 if "w" in keys else 0) - (1 if "s" in keys else 0)
            # Stick yaw is clockwise. D turns toward +X from a +Y heading.
            yaw = (1 if "d" in keys else 0) - (1 if "a" in keys else 0)
        left_right = _merge_stick(left_right, self._mouse["lr"])
        forward = _merge_stick(forward, self._mouse["fb"])
        up_down = _merge_stick(up_down, self._mouse["ud"])
        yaw = _merge_stick(yaw, self._mouse["yaw"])
        self.flight.set_channels(
            left_right * speed,
            forward * speed,
            up_down,
            yaw * speed,
            vertical_is_direction=True,
        )

    def _tick(self) -> None:
        if not self._alive:
            return
        self._send_keys()
        snap = self.flight.snapshot()
        self._paint_pose(snap)
        self._paint_logs(snap)
        self._paint_video(snap)
        self._paint_map(snap)
        self._paint_buttons(snap)
        self._offer_entry(snap)
        self.root.after(30, self._tick)

    def _paint_pose(self, snap: Snapshot) -> None:
        self.readouts["x"].configure(text=f"{snap.x:6.1f} cm")
        self.readouts["y"].configure(text=f"{snap.y:6.1f} cm")
        self.readouts["z"].configure(text=f"{snap.z:6.1f} cm")
        shown = int(round(wrap_360(snap.yaw))) % 360
        self.readouts["yaw"].configure(text=f"{shown:3d}°  {yaw_name(snap.yaw)}")
        fence = "holding at the wall" if snap.fence_holding else "inside the room"
        battery = "—" if snap.battery is None else f"{snap.battery}%"
        calibration = snap.calibration or "no file"
        self.detail.configure(
            text=(
                f"Yaw 0 faces +Y. Yaw 90 faces +X. "
                f"Source {snap.source}. {snap.orb_note} File {calibration}. "
                f"Battery {battery}. Fence {fence}."
            )
        )
        if not snap.slam3 and snap.orb_note == "ORB-SLAM3 did not start." and self.slam3_var.get():
            self.slam3_var.set(0)
        file_label = snap.calibration or "No file loaded"
        if self.yaml_file.cget("text") != file_label:
            self.yaml_file.configure(text=file_label)
        self.status.configure(text=snap.message)
        self._paint_corrections()

    def _paint_logs(self, snap: Snapshot) -> None:
        self._fill_log(self.output_box, snap.output_log, "output")
        self._fill_log(self.command_box, snap.command_log, "command")

    def _fill_log(self, widget: tk.Text, lines: tuple[str, ...], kind: str) -> None:
        text = "\n".join(lines)
        shown = self._output_shown if kind == "output" else self._command_shown
        if shown == text:
            return
        at_end = widget.yview()[1] >= 0.98 or not shown
        widget.delete("1.0", "end")
        if text:
            widget.insert("1.0", text)
        if at_end:
            widget.see("end")
        if kind == "output":
            self._output_shown = text
        else:
            self._command_shown = text

    def _paint_corrections(self) -> None:
        scale = self.flight.axis_scale()
        text = (
            "Positive X moves right and positive Y moves forward. "
            "Type how far it really went, then Save. "
            f"Saved actual cm per 100: forward {scale.forward:g}, back {scale.back:g}, "
            f"left {scale.left:g}, right {scale.right:g}."
        )
        if self.correction_label.cget("text") != text:
            self.correction_label.configure(text=text)

    def _offer_entry(self, snap: Snapshot) -> None:
        entries = [self.pose_vars[key + "_entry"] for key in ("x", "y", "z", "yaw")]
        state = "disabled" if snap.busy else "normal"
        for entry in entries:
            entry.configure(state=state)
        self.apply_button.configure(state=state)

    def _paint_buttons(self, snap: Snapshot) -> None:
        self.connect_button.configure(state="disabled" if snap.connected or snap.connecting or snap.busy else "normal")
        self.takeoff_button.configure(
            state="normal" if not snap.flying and not snap.busy else "disabled"
        )
        self.land_button.configure(state="normal" if snap.flying and not snap.busy else "disabled")
        self.emergency_button.configure(state="normal" if snap.connected else "disabled")
        go_state = "normal" if snap.flying and not snap.busy else "disabled"
        for button in self.go_buttons:
            button.configure(state=go_state)
        move_state = "normal" if snap.flying and not snap.busy else "disabled"
        for button in self.move_buttons.values():
            button.configure(state=move_state)

    def _paint_video(self, snap: Snapshot) -> None:
        frame = self.flight.copy_frame()
        if frame is None:
            if self._photo is None:
                self.video.configure(image="", text=snap.video_note)
            return
        try:
            frame = mark_view(frame)
        except Exception:
            pass
        image = Image.fromarray(frame)
        width = max(self.video.winfo_width(), 320)
        height = max(self.video.winfo_height(), 240)
        image = image.resize((width, height), Image.Resampling.BILINEAR)
        self._photo = ImageTk.PhotoImage(image)
        self.video.configure(image=self._photo, text="")

    def _paint_map(self, snap: Snapshot) -> None:
        canvas = self.map
        canvas.delete("all")
        margin = 18
        usable = MAP_SIZE - 2 * margin
        cage_x = max(snap.cage_x, 1.0)
        cage_y = max(snap.cage_y, 1.0)
        cage_z = max(snap.cage_z, 1.0)
        span = max(cage_x, cage_y)
        low, high = flyable_bounds((cage_x, cage_y, cage_z))

        def point(x_cm: float, y_cm: float) -> tuple[float, float]:
            sx = margin + (x_cm / span) * usable
            sy = margin + ((cage_y - y_cm) / span) * usable
            return sx, sy

        x0, y0 = point(0, cage_y)
        x1, y1 = point(cage_x, 0)
        canvas.create_rectangle(x0, y0, x1, y1, outline="#6d7685", width=2)
        ix0, iy0 = point(low[0], high[1])
        ix1, iy1 = point(high[0], low[1])
        canvas.create_rectangle(ix0, iy0, ix1, iy1, outline="#3a4250", dash=(3, 3))
        canvas.create_text(MAP_SIZE - 14, MAP_SIZE - 10, text="X", fill=MUTED, font=("Segoe UI", 9))
        canvas.create_text(14, 12, text="Y", fill=MUTED, font=("Segoe UI", 9))

        origin_x, origin_y = point(
            min(cage_x, max(0, snap.start_x)),
            min(cage_y, max(0, snap.start_y)),
        )
        canvas.create_oval(
            origin_x - 5,
            origin_y - 5,
            origin_x + 5,
            origin_y + 5,
            outline="#8eb4ff",
            width=2,
        )

        cx, cy = point(min(cage_x, max(0, snap.x)), min(cage_y, max(0, snap.y)))
        yaw = math.radians(snap.yaw)
        nose = (math.sin(yaw), -math.cos(yaw))
        right = (math.cos(yaw), math.sin(yaw))
        length = 16
        width = 7
        nose_x = cx + nose[0] * length
        nose_y = cy + nose[1] * length
        left_x = cx - nose[0] * 8 + right[0] * width
        left_y = cy - nose[1] * 8 + right[1] * width
        right_x = cx - nose[0] * 8 - right[0] * width
        right_y = cy - nose[1] * 8 - right[1] * width
        color = HOLD if snap.fence_holding else "#f2f4f8"
        canvas.create_polygon(nose_x, nose_y, left_x, left_y, right_x, right_y, fill=color, outline=color)

        bar = self.z_bar
        bar.delete("all")
        bar.create_rectangle(6, 18, 16, MAP_SIZE - 18, outline="#6d7685")
        z = min(cage_z, max(0.0, snap.z))
        top = 18 + ((cage_z - z) / cage_z) * (MAP_SIZE - 36)
        bar.create_rectangle(7, top, 15, MAP_SIZE - 18, fill="#8eb4ff", outline="")
        bar.create_text(11, 10, text="Z", fill=MUTED, font=("Segoe UI", 8))

    def _scroll_region(self, _event) -> None:
        if self._fitting:
            return
        box = self._scroll.bbox("all")
        if box is not None:
            self._scroll.configure(scrollregion=box)

    def _scroll_width(self, event) -> None:
        if self._fitting:
            return
        self._fitting = True
        try:
            self._scroll.itemconfigure(self._scroll_window, width=event.width)
            self._scroll.update_idletasks()
            needed = self._page.winfo_reqheight()
            height = max(event.height, needed)
            self._scroll.itemconfigure(self._scroll_window, height=height)
            self._scroll.configure(scrollregion=(0, 0, event.width, height))
        finally:
            self._fitting = False

    def _on_mousewheel(self, event) -> None:
        if self._closing or not event.delta:
            return
        if event.widget in (self.output_box, self.command_box):
            event.widget.yview_scroll(int(-event.delta / 120), "units")
            return
        self._scroll.yview_scroll(int(-event.delta / 120), "units")

    def _on_close(self) -> None:
        if self._closing:
            return
        self._closing = True
        self._alive = False
        self._keys.clear()
        self.flight.set_channels(0, 0, 0, 0)
        self.status.configure(text="Landing and disconnecting.")
        self.root.update_idletasks()
        try:
            self.root.unbind_all("<MouseWheel>")
        except tk.TclError:
            pass
        self.flight.shutdown()
        self.root.destroy()


def _last_files_path() -> Path:
    return Path(__file__).resolve().parent / "last_files.json"


def _read_last_files() -> dict:
    try:
        payload = json.loads(_last_files_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return {}
    if not isinstance(payload, dict):
        return {}
    return payload


def _saved_path(payload: dict, kind: str) -> Path | None:
    value = payload.get(kind)
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value)


def _remembered_dir(kind: str, fallback: Path) -> Path:
    saved = _saved_path(_read_last_files(), kind)
    if saved is not None and saved.parent.is_dir():
        return saved.parent
    return fallback


def _remember_file(kind: str, path: Path) -> None:
    payload = _read_last_files()
    payload[kind] = str(path)
    try:
        _last_files_path().write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    except OSError:
        pass


def _newest_zip(folder: Path) -> Path | None:
    if not folder.is_dir():
        return None
    files = [item for item in folder.iterdir() if item.is_file() and item.suffix.lower() == ".zip"]
    if not files:
        return None
    return max(files, key=lambda item: item.stat().st_mtime)


def _format_start(value: float) -> str:
    shown = float(value)
    if shown.is_integer():
        return str(int(shown))
    return f"{shown:.1f}"


def _shade(hex_color: str, factor: float) -> str:
    """Darken or lighten a #rrggbb color. Values stay inside 0 to 255."""
    red = int(hex_color[1:3], 16)
    green = int(hex_color[3:5], 16)
    blue = int(hex_color[5:7], 16)

    def channel(value: int) -> int:
        return max(0, min(255, int(round(value * factor))))

    return f"#{channel(red):02x}{channel(green):02x}{channel(blue):02x}"


def _number_message(error: ValueError, fallback: str) -> str:
    text = str(error)
    if "could not convert" in text or "invalid literal" in text:
        return fallback
    return text


def _merge_stick(key_axis: int, mouse_axis: int) -> int:
    return max(-1, min(1, key_axis + mouse_axis))


def main() -> None:
    FlightWindow().run()


if __name__ == "__main__":
    main()
