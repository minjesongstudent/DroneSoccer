#!/bin/bash
# Builds a headless ORB-SLAM3 monocular worker in the WSL home directory.
set -euo pipefail

ROOT="$HOME/orbslam3-build"
mkdir -p "$ROOT"
cd "$ROOT"

if [ ! -f eigen/Eigen/Core ]; then
  curl -L --retry 3 -o eigen.tar.gz https://gitlab.com/libeigen/eigen/-/archive/3.4.0/eigen-3.4.0.tar.gz
  rm -rf eigen eigen-3.4.0
  tar -xf eigen.tar.gz
  mv eigen-3.4.0 eigen
fi

if [ ! -d opencv/modules/core ]; then
  curl -L --retry 3 -o opencv.tar.gz https://github.com/opencv/opencv/archive/refs/tags/4.10.0.tar.gz
  rm -rf opencv opencv-4.10.0
  tar -xf opencv.tar.gz
  mv opencv-4.10.0 opencv
fi

if [ ! -f install/lib/libopencv_core.so ]; then
  cmake -S opencv -B opencv/build \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$ROOT/install" \
    -DBUILD_LIST=core,imgproc,features2d,flann,calib3d \
    -DBUILD_SHARED_LIBS=ON \
    -DWITH_EIGEN=OFF \
    -DWITH_GTK=OFF \
    -DWITH_QT=OFF \
    -DWITH_FFMPEG=OFF \
    -DWITH_IPP=OFF \
    -DWITH_JPEG=ON \
    -DWITH_PNG=ON \
    -DWITH_TIFF=OFF \
    -DWITH_WEBP=OFF \
    -DWITH_OPENJPEG=OFF \
    -DWITH_JASPER=OFF \
    -DWITH_OPENEXR=OFF \
    -DWITH_PROTOBUF=OFF \
    -DBUILD_PROTOBUF=OFF \
    -DWITH_ITT=OFF \
    -DWITH_QUIRC=OFF \
    -DBUILD_TESTS=OFF \
    -DBUILD_PERF_TESTS=OFF \
    -DBUILD_EXAMPLES=OFF \
    -DBUILD_opencv_apps=OFF \
    -DBUILD_JAVA=OFF \
    -DBUILD_opencv_python2=OFF \
    -DBUILD_opencv_python3=OFF
  cmake --build opencv/build -j 8
  cmake --install opencv/build
fi

if [ ! -d ORB_SLAM3/.git ]; then
  git clone --depth 1 https://github.com/UZ-SLAMLab/ORB_SLAM3.git ORB_SLAM3
fi

echo "deps ready"
