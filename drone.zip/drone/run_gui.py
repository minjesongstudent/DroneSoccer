import cv2
import numpy as np
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

class DroneCalibratorUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Drone Camera Calibration for ORB-SLAM3")
        self.root.geometry("1040x780")

        self.objpoints = []
        self.imgpoints = []
        self.cap = None
        self.running = False
        self.current_corners = None
        self.current_gray = None
        self.img_size = None

        self.create_widgets()

    def create_widgets(self):
        # Section 1: Settings
        top_frame = ttk.LabelFrame(self.root, text=" 1. Connection & Checkerboard Settings ")
        top_frame.pack(fill="x", padx=10, pady=5)

        # Drone Stream URL
        ttk.Label(top_frame, text="Drone Stream URL:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.src_entry = ttk.Entry(top_frame, width=32)
        # Default IP set to 192.168.10.1 (change protocol/port if necessary, e.g., udp://... or http://...)
        self.src_entry.insert(0, "rtsp://192.168.10.1:554/stream")
        self.src_entry.grid(row=0, column=1, padx=5, pady=5)

        # Total Squares on A4 (Width x Height)
        ttk.Label(top_frame, text="Total Squares (W x H):").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.squares_entry = ttk.Entry(top_frame, width=8)
        self.squares_entry.insert(0, "9x7")  # Standard pattern on A4 has 9x7 squares (which yields 8x6 corners)
        self.squares_entry.grid(row=0, column=3, padx=5, pady=5)

        # Square size in cm
        ttk.Label(top_frame, text="Square Size (cm):").grid(row=0, column=4, padx=5, pady=5, sticky="w")
        self.size_cm_entry = ttk.Entry(top_frame, width=8)
        self.size_cm_entry.insert(0, "2.5")  # e.g., 2.5 cm
        self.size_cm_entry.grid(row=0, column=5, padx=5, pady=5)

        # Connect / Disconnect Button
        self.btn_connect = ttk.Button(top_frame, text="Connect Stream", command=self.toggle_stream)
        self.btn_connect.grid(row=0, column=6, padx=10, pady=5)

        # Display internal corners info
        self.lbl_corners_info = ttk.Label(
            top_frame, 
            text="* Internal Corners: Calculated automatically as (Squares - 1)", 
            font=("Arial", 8, "italic")
        )
        self.lbl_corners_info.grid(row=1, column=0, columnspan=7, padx=5, pady=2, sticky="w")

        # Center: Live Video Feed
        self.video_label = ttk.Label(self.root)
        self.video_label.pack(expand=True, fill="both", padx=10, pady=5)

        # Section 2: Controls & Actions
        bottom_frame = ttk.LabelFrame(self.root, text=" 2. Capture & Calibration ")
        bottom_frame.pack(fill="x", padx=10, pady=5)

        self.btn_capture = ttk.Button(
            bottom_frame, 
            text="📷 Capture Frame (Spacebar)", 
            command=self.capture_frame, 
            state="disabled"
        )
        self.btn_capture.pack(side="left", padx=10, pady=8)

        self.btn_calc = ttk.Button(
            bottom_frame, 
            text="💾 Calibrate & Export ORB-SLAM3 YAML", 
            command=self.calibrate_and_save, 
            state="disabled"
        )
        self.btn_calc.pack(side="left", padx=10, pady=8)

        self.lbl_status = ttk.Label(
            bottom_frame, 
            text="Captured Frames: 0 (Recommended: 15~25)", 
            font=("Arial", 10, "bold")
        )
        self.lbl_status.pack(side="right", padx=15, pady=8)

        # Shortcut: Spacebar for capture
        self.root.bind("<space>", lambda e: self.capture_frame())

    def get_corner_dimensions(self):
        """Calculates inner corners from total squares: (Squares_W - 1, Squares_H - 1)"""
        try:
            sq_w, sq_h = map(int, self.squares_entry.get().lower().split('x'))
            if sq_w <= 1 or sq_h <= 1:
                return (8, 6)
            return (sq_w - 1, sq_h - 1)
        except Exception:
            return (8, 6)

    def toggle_stream(self):
        if not self.running:
            src = self.src_entry.get().strip()
            if src.isdigit():
                src = int(src)

            self.cap = cv2.VideoCapture(src)
            if not self.cap.isOpened():
                messagebox.showerror("Connection Error", f"Unable to open video stream:\n{src}")
                return

            self.running = True
            self.btn_connect.config(text="Disconnect Stream")
            self.btn_capture.config(state="normal")
            self.btn_calc.config(state="normal")
            self.update_video()
        else:
            self.running = False
            if self.cap:
                self.cap.release()
            self.btn_connect.config(text="Connect Stream")
            self.btn_capture.config(state="disabled")

    def update_video(self):
        if not self.running:
            return

        ret, frame = self.cap.read()
        if ret:
            self.current_gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            self.img_size = (self.current_gray.shape[1], self.current_gray.shape[0])

            # Get target corners (W - 1, H - 1)
            board_corners = self.get_corner_dimensions()

            # Detect checkerboard
            found, corners = cv2.findChessboardCorners(
                self.current_gray, board_corners,
                cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_FAST_CHECK + cv2.CALIB_CB_NORMALIZE_IMAGE
            )

            display_img = frame.copy()
            if found:
                self.current_corners = cv2.cornerSubPix(
                    self.current_gray, corners, (11, 11), (-1, -1),
                    (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
                )
                cv2.drawChessboardCorners(display_img, board_corners, self.current_corners, found)
                cv2.putText(
                    display_img, 
                    f"STATUS: Board Detected ({board_corners[0]}x{board_corners[1]} corners)! Press Space", 
                    (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2
                )
            else:
                self.current_corners = None
                cv2.putText(
                    display_img, 
                    f"STATUS: Looking for {board_corners[0]}x{board_corners[1]} corners...", 
                    (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2
                )

            # Resize to fit UI window
            rgb_img = cv2.cvtColor(display_img, cv2.COLOR_BGR2RGB)
            h, w = rgb_img.shape[:2]
            scale = min(960 / w, 540 / h)
            resized = cv2.resize(rgb_img, (int(w * scale), int(h * scale)))

            img_tk = ImageTk.PhotoImage(image=Image.fromarray(resized))
            self.video_label.imgtk = img_tk
            self.video_label.configure(image=img_tk)

        self.root.after(20, self.update_video)

    def capture_frame(self):
        if not self.running or self.current_corners is None:
            return

        cw, ch = self.get_corner_dimensions()
        
        # Convert square size from cm to meters (1 cm = 0.01 m)
        try:
            sq_size_m = float(self.size_cm_entry.get()) * 0.01
        except ValueError:
            sq_size_m = 0.025

        objp = np.zeros((cw * ch, 3), np.float32)
        objp[:, :2] = np.mgrid[0:cw, 0:ch].T.reshape(-1, 2) * sq_size_m

        self.objpoints.append(objp)
        self.imgpoints.append(self.current_corners)

        count = len(self.imgpoints)
        self.lbl_status.config(text=f"Captured Frames: {count} (Recommended: 15~25)")
        print(f"[Capture] Frame #{count} added successfully.")

    def calibrate_and_save(self):
        if len(self.imgpoints) < 10:
            messagebox.showwarning(
                "Insufficient Data", 
                f"Please capture at least 10 frames (currently: {len(self.imgpoints)})."
            )
            return

        # OpenCV Camera Calibration
        ret, K, dist, _, _ = cv2.calibrateCamera(
            self.objpoints, self.imgpoints, self.img_size, None, None
        )

        fx, fy = float(K[0, 0]), float(K[1, 1])
        cx, cy = float(K[0, 2]), float(K[1, 2])
        k1, k2, p1, p2 = float(dist[0][0]), float(dist[0][1]), float(dist[0][2]), float(dist[0][3])

        # ORB-SLAM3 YAML Specification
        yaml_content = f"""%YAML:1.0

#--------------------------------------------------------------------------------------------
# Camera Parameters for ORB-SLAM3
#--------------------------------------------------------------------------------------------
File.version: "1.0"

Camera.type: "PinHole"

# Camera calibration and distortion parameters (OpenCV)
Camera1.fx: {fx:.6f}
Camera1.fy: {fy:.6f}
Camera1.cx: {cx:.6f}
Camera1.cy: {cy:.6f}

Camera1.k1: {k1:.6f}
Camera1.k2: {k2:.6f}
Camera1.p1: {p1:.6f}
Camera1.p2: {p2:.6f}

# Camera resolution & framerate
Camera.width: {self.img_size[0]}
Camera.height: {self.img_size[1]}
Camera.fps: 30
Camera.RGB: 1

#--------------------------------------------------------------------------------------------
# ORB Parameters
#--------------------------------------------------------------------------------------------
ORBextractor.nFeatures: 1200
ORBextractor.scaleFactor: 1.2
ORBextractor.nLevels: 8
ORBextractor.iniThFAST: 20
ORBextractor.minThFAST: 7

#--------------------------------------------------------------------------------------------
# Viewer Parameters
#--------------------------------------------------------------------------------------------
Viewer.KeyFrameSize: 0.05
Viewer.KeyFrameLineWidth: 1.0
Viewer.GraphLineWidth: 0.9
Viewer.PointSize: 2.0
Viewer.CameraSize: 0.08
Viewer.CameraLineWidth: 3.0
Viewer.ViewpointX: 0.0
Viewer.ViewpointY: -0.7
Viewer.ViewpointZ: -1.8
Viewer.ViewpointF: 500.0
"""
        output_filename = "drone_orbslam3.yaml"
        with open(output_filename, "w") as f:
            f.write(yaml_content)

        messagebox.showinfo(
            "Calibration Complete", 
            f"Calibration finished successfully!\n\n"
            f"Reprojection Error (RMS): {ret:.4f}\n"
            f"Output file: {output_filename}"
        )

if __name__ == "__main__":
    root = tk.Tk()
    app = DroneCalibratorUI(root)
    root.mainloop()