"""ORB-SLAM3 monocular worker running in WSL.

The worker is the ORB-SLAM3 library. This side sends grayscale frames and
turns the returned camera pose into a right/forward step in centimetres.
"""

from __future__ import annotations

import math
import socket
import struct
import subprocess
import threading
from pathlib import Path

import cv2
import numpy as np

WORKER = "/home/min/orbslam3-build/worker"
VOCABULARY = "/home/min/orbslam3-build/ORB_SLAM3/Vocabulary/ORBvoc.txt"
LIBRARY_PATH = ":".join(
    (
        "/home/min/orbslam3-build/install/lib",
        "/home/min/orbslam3-build/ORB_SLAM3/lib",
        "/home/min/orbslam3-build/ORB_SLAM3/Thirdparty/DBoW2/lib",
        "/home/min/orbslam3-build/ORB_SLAM3/Thirdparty/g2o/lib",
        "/home/min/orbslam3-build/local/lib",
        "/home/min/orbslam3-build/sysroot/usr/lib/x86_64-linux-gnu",
        "/usr/lib/x86_64-linux-gnu",
    )
)
# ORB-SLAM3 tracking states that still carry a camera pose.
_POSE_STATES = {2, 3, 5}


class OrbSlam3Session:
    """One long-lived ORB-SLAM3 process and its socket."""

    def __init__(self) -> None:
        self._proc: subprocess.Popen[str] | None = None
        self._sock: socket.socket | None = None
        self._pump: threading.Thread | None = None
        self._tail = ""
        self._lock = threading.Lock()

    def start(self, settings_yaml: Path) -> None:
        """Load the vocabulary and the YAML. Raises RuntimeError when that fails."""
        self.close()
        if not settings_yaml.is_file():
            raise RuntimeError("That ORB-SLAM3 YAML is not there.")
        command = (
            f"export LD_LIBRARY_PATH='{LIBRARY_PATH}'; "
            f"exec '{WORKER}' '{VOCABULARY}' '{_wsl_path(settings_yaml)}'"
        )
        try:
            proc = subprocess.Popen(
                ["wsl", "-d", "Ubuntu", "--", "bash", "-lc", command],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
            )
        except OSError as ex:
            raise RuntimeError("Windows could not start WSL.") from ex
        self._proc = proc
        self._pump = threading.Thread(target=self._read_output, args=(proc,), daemon=True)
        self._pump.start()
        ready = self._wait_ready(proc)
        if ready is None:
            detail = self._tail.strip() or "ORB-SLAM3 did not start."
            self.close()
            raise RuntimeError(detail)
        sock = socket.create_connection(("127.0.0.1", ready), timeout=10)
        sock.settimeout(8.0)
        self._sock = sock

    def reset(self) -> None:
        """Clear the map. The next frame starts initialization again."""
        with self._lock:
            sock = self._sock
            if sock is None:
                return
            sock.sendall(struct.pack("<B", 2))
            ack = _recv_exact(sock, 4)
            if ack is None:
                raise RuntimeError("ORB-SLAM3 reset failed.")

    def track(self, rgb: np.ndarray, timestamp: float, width: int, height: int) -> tuple[int, tuple[float, ...] | None]:
        """Send one frame. The matrix is row-major Tcw, or None while the pose is not usable."""
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        if gray.shape[1] != width or gray.shape[0] != height:
            gray = cv2.resize(gray, (width, height), interpolation=cv2.INTER_AREA)
        payload = np.ascontiguousarray(gray, dtype=np.uint8).tobytes()
        header = struct.pack("<BII d", 1, width, height, float(timestamp))
        with self._lock:
            sock = self._sock
            if sock is None:
                raise RuntimeError("ORB-SLAM3 is not running.")
            sock.sendall(header + payload)
            state_bits = _recv_exact(sock, 4)
            valid_bits = _recv_exact(sock, 1)
            matrix_bits = _recv_exact(sock, 16 * 8)
        if state_bits is None or valid_bits is None or matrix_bits is None:
            raise RuntimeError("ORB-SLAM3 stopped answering.")
        state = struct.unpack("<i", state_bits)[0]
        valid = struct.unpack("<B", valid_bits)[0]
        matrix = struct.unpack("<16d", matrix_bits)
        if valid and state in _POSE_STATES:
            return state, matrix
        return state, None

    def close(self) -> None:
        sock = self._sock
        self._sock = None
        if sock is not None:
            try:
                sock.sendall(struct.pack("<B", 3))
            except OSError:
                pass
            sock.close()
        proc = self._proc
        self._proc = None
        if proc is not None and proc.poll() is None:
            try:
                proc.wait(timeout=3)
            except subprocess.TimeoutExpired:
                proc.kill()

    def _read_output(self, proc: subprocess.Popen[str]) -> None:
        stream = proc.stdout
        if stream is None:
            return
        for line in stream:
            self._tail = (self._tail + line)[-2000:]

    def _wait_ready(self, proc: subprocess.Popen[str]) -> int | None:
        deadline = threading.Event()

        def watch() -> None:
            deadline.wait(40)

        timer = threading.Thread(target=watch, daemon=True)
        timer.start()
        started = time_wait_ready(proc, self)
        deadline.set()
        return started


def time_wait_ready(proc: subprocess.Popen[str], session: OrbSlam3Session) -> int | None:
    """Block until the worker prints its port, the process exits, or 40 seconds pass."""
    import time

    end = time.perf_counter() + 90.0
    while time.perf_counter() < end:
        if proc.poll() is not None:
            return None
        tail = session._tail
        if "ready " in tail:
            line = [item for item in tail.splitlines() if item.startswith("ready ")]
            if line:
                return int(line[-1].split()[1])
        time.sleep(0.05)
    return None


def room_step(
    origin: tuple[float, ...],
    current: tuple[float, ...],
    scale_cm: float,
) -> tuple[float, float, float]:
    """Right cm, forward cm, and clockwise yaw change from the anchor camera pose.

    Both matrices are row-major ORB-SLAM3 Tcw. X of the camera is right and Z is forward.
    """
    moved = _camera_center(current)
    start = _camera_center(origin)
    delta_world = (moved[0] - start[0], moved[1] - start[1], moved[2] - start[2])
    delta_camera = _rotate(origin, delta_world)
    forward_world = (current[8], current[9], current[10])
    forward_camera = _rotate(origin, forward_world)
    yaw_deg = math.degrees(math.atan2(forward_camera[0], forward_camera[2]))
    return (delta_camera[0] * scale_cm, delta_camera[2] * scale_cm, yaw_deg)


def _camera_center(matrix: tuple[float, ...]) -> tuple[float, float, float]:
    """Camera centre in the SLAM world. Tcw stores the inverse translation."""
    rotation_t_times_t = (
        matrix[0] * matrix[3] + matrix[4] * matrix[7] + matrix[8] * matrix[11],
        matrix[1] * matrix[3] + matrix[5] * matrix[7] + matrix[9] * matrix[11],
        matrix[2] * matrix[3] + matrix[6] * matrix[7] + matrix[10] * matrix[11],
    )
    return (-rotation_t_times_t[0], -rotation_t_times_t[1], -rotation_t_times_t[2])


def _rotate(matrix: tuple[float, ...], vector: tuple[float, float, float]) -> tuple[float, float, float]:
    """Apply the rotation inside a row-major Tcw."""
    return (
        matrix[0] * vector[0] + matrix[1] * vector[1] + matrix[2] * vector[2],
        matrix[4] * vector[0] + matrix[5] * vector[1] + matrix[6] * vector[2],
        matrix[8] * vector[0] + matrix[9] * vector[1] + matrix[10] * vector[2],
    )


def _wsl_path(path: Path) -> str:
    resolved = path.resolve()
    drive = resolved.drive.rstrip(":").lower()
    if not drive:
        return resolved.as_posix()
    rest = resolved.as_posix().split(":", 1)[1]
    return f"/mnt/{drive}{rest}"


def _recv_exact(sock: socket.socket, size: int) -> bytes | None:
    chunks = bytearray()
    while len(chunks) < size:
        try:
            piece = sock.recv(size - len(chunks))
        except socket.timeout:
            return None
        if not piece:
            return None
        chunks.extend(piece)
    return bytes(chunks)


def _check() -> None:
    identity = (
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    )
    # Camera translated 0.2 map units forward. Tcw translation is the inverse.
    forward = (
        1.0, 0.0, 0.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        0.0, 0.0, 1.0, -0.2,
        0.0, 0.0, 0.0, 1.0,
    )
    right, ahead, yaw = room_step(identity, forward, 100.0)
    assert abs(right) < 1e-9 and abs(ahead - 20.0) < 1e-9 and abs(yaw) < 1e-9
    # Camera yawed so its forward axis points to the old camera-right.
    turned = (
        0.0, 0.0, -1.0, 0.0,
        0.0, 1.0, 0.0, 0.0,
        1.0, 0.0, 0.0, 0.0,
        0.0, 0.0, 0.0, 1.0,
    )
    right, ahead, yaw = room_step(identity, turned, 100.0)
    assert abs(right) < 1e-6 and abs(ahead) < 1e-6 and abs(yaw - 90.0) < 1e-6
    assert _wsl_path(Path(r"D:\codebymin\classes\drone\tello_orbslam3.yaml")).startswith("/mnt/d/")


if __name__ == "__main__":
    _check()
    print("orbslam3 client ok")
