#!/bin/bash
set -euo pipefail
ROOT="$HOME/orbslam3-build"
cd "$ROOT"
cmake -S opencv -B opencv/build \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_INSTALL_PREFIX="$ROOT/install" \
  -DBUILD_LIST=core,imgproc,features2d,flann,calib3d,highgui \
  -DBUILD_SHARED_LIBS=ON \
  -DWITH_EIGEN=OFF \
  -DWITH_GTK=OFF \
  -DWITH_QT=OFF \
  -DWITH_FFMPEG=OFF \
  -DWITH_IPP=OFF \
  -DWITH_JPEG=ON \
  -DWITH_PNG=ON \
  -DWITH_TIFF=OFF \
  -DWITH_WEBP=OFF \
  -DWITH_OPENJPEG=OFF \
  -DWITH_JASPER=OFF \
  -DWITH_OPENEXR=OFF \
  -DWITH_PROTOBUF=OFF \
  -DBUILD_PROTOBUF=OFF \
  -DWITH_ITT=OFF \
  -DWITH_QUIRC=OFF \
  -DBUILD_TESTS=OFF \
  -DBUILD_PERF_TESTS=OFF \
  -DBUILD_EXAMPLES=OFF \
  -DBUILD_opencv_apps=OFF \
  -DBUILD_JAVA=OFF \
  -DBUILD_opencv_python2=OFF \
  -DBUILD_opencv_python3=OFF
cmake --build opencv/build -j 8
cmake --install opencv/build
echo highgui ready
