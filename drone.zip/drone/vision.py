"""Light edge marks for the forward camera.

Magenta follows the hoover rim. Green follows net ropes where two rope
directions cross. A frame with neither pattern is left unchanged.
"""

from __future__ import annotations

import math

import cv2
import numpy as np

HOOVER_COLOR = (255, 0, 200)
NET_COLOR = (40, 255, 90)

# OpenCV hue is 0 to 180. The foam ring sits around hue 100.
_HOOVER_LOW = (85, 45, 40)
_HOOVER_HIGH = (125, 255, 255)
_WORK_WIDTH = 640


def mark_view(rgb: np.ndarray) -> np.ndarray:
    """Return a copy of an RGB frame with hoover and net edges drawn."""
    if rgb is None or getattr(rgb, "ndim", 0) != 3 or rgb.shape[2] != 3 or rgb.dtype != np.uint8:
        return rgb
    height, width = rgb.shape[:2]
    scale = 1.0
    work = rgb
    if width > _WORK_WIDTH:
        scale = _WORK_WIDTH / width
        work = cv2.resize(rgb, (_WORK_WIDTH, max(1, int(height * scale))), interpolation=cv2.INTER_AREA)
    marked = _mark(work)
    if scale != 1.0:
        marked = cv2.resize(marked, (width, height), interpolation=cv2.INTER_LINEAR)
    return marked


def _mark(rgb: np.ndarray) -> np.ndarray:
    marked = np.array(rgb, copy=True)
    hoover_mask = _hoover_mask(marked)
    _draw_hoover(marked, hoover_mask)
    _draw_net(marked, hoover_mask)
    return marked


def _hoover_mask(rgb: np.ndarray) -> np.ndarray:
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    mask = cv2.inRange(hsv, _HOOVER_LOW, _HOOVER_HIGH)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return mask


def _draw_hoover(marked: np.ndarray, mask: np.ndarray) -> None:
    height, width = mask.shape[:2]
    minimum = 0.008 * height * width
    contours, _hierarchy = cv2.findContours(mask, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    kept = [contour for contour in contours if cv2.contourArea(contour) >= minimum]
    if not kept:
        return
    cv2.drawContours(marked, kept, -1, HOOVER_COLOR, 3, lineType=cv2.LINE_AA)


def _draw_net(marked: np.ndarray, hoover_mask: np.ndarray) -> None:
    gray = cv2.cvtColor(marked, cv2.COLOR_RGB2GRAY)
    # Black-hat keeps thin dark ropes and drops wide surfaces such as the floor.
    hat = cv2.morphologyEx(gray, cv2.MORPH_BLACKHAT, cv2.getStructuringElement(cv2.MORPH_RECT, (11, 11)))
    _level, thin = cv2.threshold(hat, 18, 255, cv2.THRESH_BINARY)
    blocked = cv2.dilate(hoover_mask, np.ones((11, 11), np.uint8))
    thin = cv2.bitwise_and(thin, cv2.bitwise_not(blocked))
    lines = cv2.HoughLinesP(thin, 1, np.pi / 180, 20, minLineLength=12, maxLineGap=6)
    segments = _line_segments(lines)
    chosen = _grid_segments(segments, thin.shape[0], thin.shape[1])
    for x1, y1, x2, y2 in chosen:
        cv2.line(marked, (x1, y1), (x2, y2), NET_COLOR, 2, lineType=cv2.LINE_AA)


def _line_segments(lines: np.ndarray | None) -> list[tuple[int, int, int, int, float]]:
    if lines is None:
        return []
    flat = np.asarray(lines).reshape(-1, 4)
    segments = []
    for x1, y1, x2, y2 in flat:
        angle = math.degrees(math.atan2(float(y2 - y1), float(x2 - x1))) % 180.0
        segments.append((int(x1), int(y1), int(x2), int(y2), angle))
    return segments


def _grid_segments(
    segments: list[tuple[int, int, int, int, float]],
    height: int,
    width: int,
) -> list[tuple[int, int, int, int]]:
    """Keep rope segments only where two mesh directions cross."""
    if len(segments) < 12:
        return []
    bins = [0] * 12
    for _x1, _y1, _x2, _y2, angle in segments:
        bins[int(angle // 15) % 12] += 1
    first = max(range(12), key=lambda index: bins[index])
    if bins[first] < 8:
        return []
    second = max(((first + offset) % 12 for offset in range(4, 9)), key=lambda index: bins[index])
    if bins[second] < 6:
        return []
    centers = (first * 15 + 7.5, second * 15 + 7.5)
    cell = 40
    rows = height // cell + 1
    cols = width // cell + 1
    count_a = np.zeros((rows, cols), np.int16)
    count_b = np.zeros((rows, cols), np.int16)
    grouped: list[tuple[int, int, int, int, int]] = []
    for x1, y1, x2, y2, angle in segments:
        group = _direction_index(angle, centers)
        if group is None:
            continue
        row, col = _cell_of((y1 + y2) // 2, (x1 + x2) // 2, cell, rows, cols)
        if group == 0:
            count_a[row, col] += 1
        else:
            count_b[row, col] += 1
        grouped.append((x1, y1, x2, y2, group))
    net = (count_a >= 1) & (count_b >= 1)
    if int(net.sum()) < 4:
        return []
    grown = _grow(net)
    chosen = []
    for x1, y1, x2, y2, _group in grouped:
        row, col = _cell_of((y1 + y2) // 2, (x1 + x2) // 2, cell, rows, cols)
        if grown[row, col]:
            chosen.append((x1, y1, x2, y2))
    if len(chosen) < 8:
        return []
    return chosen


def _direction_index(angle: float, centers: tuple[float, float]) -> int | None:
    for index, center in enumerate(centers):
        if _angle_near(angle, center):
            return index
    return None


def _cell_of(y: int, x: int, cell: int, rows: int, cols: int) -> tuple[int, int]:
    return (min(rows - 1, max(0, y // cell)), min(cols - 1, max(0, x // cell)))


def _grow(mask: np.ndarray) -> np.ndarray:
    padded = np.pad(mask, 1, constant_values=False)
    rows, cols = mask.shape
    grown = np.zeros_like(mask)
    for dy in range(3):
        for dx in range(3):
            grown |= padded[dy : dy + rows, dx : dx + cols]
    return grown


def _angle_near(angle: float, center: float) -> bool:
    gap = abs(angle - center) % 180.0
    gap = min(gap, 180.0 - gap)
    return gap <= 12.0
