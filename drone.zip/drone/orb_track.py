"""Forward-camera pose from an ORB-SLAM3 PinHole YAML file.

The file supplies the camera matrix, distortion, and ORB extractor settings.
Each new frame is matched to the previous one. The essential matrix gives the
direction of the move, and the aircraft's own speed gives the distance in
centimetres. Height is not taken from the image.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

DEFAULT_YAML_DIR = Path(r"D:\codebymin\classes\Camera Calibration\yaml result")

# ORB-SLAM3 writes intrinsics as Camera1.*. Older files used Camera.*.
_INTRINSIC_FIELDS = ("fx", "fy", "cx", "cy", "k1", "k2", "p1", "p2")


@dataclass(frozen=True)
class CameraModel:
    """PinHole intrinsics and the ORB settings stored beside them."""

    fx: float
    fy: float
    cx: float
    cy: float
    k1: float
    k2: float
    p1: float
    p2: float
    k3: float
    width: int
    height: int
    fps: float = 30.0
    rgb: int = 1
    n_features: int = 1250
    scale_factor: float = 1.2
    n_levels: int = 8
    ini_th_fast: int = 20
    min_th_fast: int = 7


@dataclass(frozen=True)
class TrackStep:
    """One camera update. ``kind`` is ``move``, ``hold``, or ``lost``."""

    kind: str
    right_cm: float = 0.0
    forward_cm: float = 0.0


class OrbTracker:
    """Tracks the forward camera. The flight loop owns the room position."""

    def __init__(self) -> None:
        self.note = "Drop an ORB-SLAM3 YAML."
        self._model: CameraModel | None = None
        self._orb_ini = None
        self._orb_min = None
        self._matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        self._k: np.ndarray | None = None
        self._dist: np.ndarray | None = None
        self._prev = None

    def accepts(self, model: CameraModel) -> bool:
        return self._model is model and self._orb_ini is not None

    def configure(self, model: CameraModel) -> None:
        self._model = model
        self._orb_ini = _orb(model, model.ini_th_fast)
        self._orb_min = _orb(model, model.min_th_fast)
        self._k = None
        self._dist = np.array([model.k1, model.k2, model.p1, model.p2, model.k3], dtype=np.float64)
        self.reset()
        self.note = "Calibration loaded."

    def reset(self) -> None:
        """Forget the previous frame so the next picture starts a new track."""
        self._prev = None

    def track(
        self,
        rgb: np.ndarray,
        dt: float,
        speed_right: float,
        speed_forward: float,
    ) -> TrackStep:
        """Camera motion since the previous accepted frame, in body centimetres."""
        if self._model is None or self._orb_ini is None or self._orb_min is None or self._dist is None:
            self.note = "Drop an ORB-SLAM3 YAML."
            return TrackStep("lost")
        gray = _gray(rgb)
        if gray is None:
            self.note = "ORB lost"
            return TrackStep("lost")
        original_h, original_w = gray.shape[:2]
        scale = 1.0
        if original_w > 640:
            scale = 640.0 / original_w
            gray = cv2.resize(
                gray,
                (640, max(1, int(round(original_h * scale)))),
                interpolation=cv2.INTER_AREA,
            )
        self._ensure_matrix(original_w, original_h, scale)
        keypoints, descriptors = self._detect(gray)
        if descriptors is None or len(keypoints) < 30:
            self._prev = None
            self.note = "ORB needs more corners"
            return TrackStep("lost")
        if self._prev is None:
            self._prev = (keypoints, descriptors)
            self.note = "ORB locked"
            return TrackStep("hold")
        previous_kp, previous_des = self._prev
        self._prev = (keypoints, descriptors)
        step = self._motion(previous_kp, previous_des, keypoints, descriptors, dt, speed_right, speed_forward)
        if step.kind == "move":
            self.note = "ORB tracking"
        elif step.kind == "hold":
            self.note = "ORB holding"
        else:
            self.note = "ORB lost"
        return step

    def _detect(self, gray: np.ndarray):
        keypoints, descriptors = self._orb_ini.detectAndCompute(gray, None)
        if descriptors is None or len(keypoints) < 150:
            keypoints, descriptors = self._orb_min.detectAndCompute(gray, None)
        return keypoints, descriptors

    def _ensure_matrix(self, width: int, height: int, scale: float) -> None:
        model = self._model
        if model is None or width <= 0 or height <= 0:
            return
        sx = (width / model.width) * scale
        sy = (height / model.height) * scale
        fx = model.fx * sx
        fy = model.fy * sy
        cx = model.cx * sx
        cy = model.cy * sy
        self._k = np.array([[fx, 0.0, cx], [0.0, fy, cy], [0.0, 0.0, 1.0]], dtype=np.float64)

    def _motion(self, keypoints1, descriptors1, keypoints2, descriptors2, dt, speed_right, speed_forward) -> TrackStep:
        if self._k is None or self._dist is None:
            return TrackStep("lost")
        pairs = self._matcher.knnMatch(descriptors1, descriptors2, k=2)
        matches = []
        for pair in pairs:
            if len(pair) < 2:
                continue
            best, second = pair
            if best.distance < 0.75 * second.distance:
                matches.append(best)
        if len(matches) < 25:
            return TrackStep("lost")
        matches.sort(key=lambda item: item.distance)
        matches = matches[:400]
        points1 = _undistort(keypoints1, [item.queryIdx for item in matches], self._k, self._dist)
        points2 = _undistort(keypoints2, [item.trainIdx for item in matches], self._k, self._dist)
        essential, mask = cv2.findEssentialMat(points1, points2, self._k, cv2.RANSAC, 0.999, 1.0)
        if essential is None or mask is None or int(mask.sum()) < 25:
            return TrackStep("lost")
        inliers, rotation, translation, _pose_mask = cv2.recoverPose(
            essential, points1, points2, self._k, mask=mask
        )
        if inliers < 20:
            return TrackStep("lost")
        # recoverPose maps a point in the previous camera into the new one.
        # The new camera centre, in the previous camera, is -R^T t.
        # OpenCV camera axes are right, down, and forward.
        centre = -rotation.T @ np.asarray(translation, dtype=np.float64).reshape(3)
        kind, right, forward = scaled_body_step(float(centre[0]), float(centre[2]), speed_right, speed_forward, dt)
        return TrackStep(kind, right, forward)


def scaled_body_step(
    visual_right: float,
    visual_forward: float,
    speed_right: float,
    speed_forward: float,
    dt: float,
) -> tuple[str, float, float]:
    """Scale a unit camera step with body speed. The result is centimetres."""
    if dt <= 0:
        return ("hold", 0.0, 0.0)
    metric = math.hypot(speed_right, speed_forward) * dt
    if metric < 0.4:
        return ("hold", 0.0, 0.0)
    horiz = math.hypot(visual_right, visual_forward)
    speed = math.hypot(speed_right, speed_forward)
    if horiz < 0.25 or speed <= 0:
        return ("lost", 0.0, 0.0)
    cosine = (visual_right * speed_right + visual_forward * speed_forward) / (horiz * speed)
    if cosine < 0.2:
        return ("lost", 0.0, 0.0)
    scale = metric / horiz
    right = visual_right * scale
    forward = visual_forward * scale
    if math.hypot(right, forward) > 25.0:
        return ("lost", 0.0, 0.0)
    return ("move", right, forward)


def load_orb_yaml(path: Path) -> CameraModel:
    """Read one ORB-SLAM3 PinHole file. Raises ValueError when it is not usable."""
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8-sig")
    except OSError as ex:
        raise ValueError(f"Could not read {path.name}.") from ex
    except UnicodeError as ex:
        raise ValueError(f"{path.name} is not a text YAML file.") from ex
    if len(text) > 256_000:
        raise ValueError(f"{path.name} is too large for an ORB-SLAM3 camera file.")
    return parse_orb_yaml(text, path.name)


def _intrinsic_key(values: dict[str, str], field: str) -> str | None:
    for key in (f"Camera1.{field}", f"Camera.{field}"):
        if key in values:
            return key
    return None


def parse_orb_yaml(text: str, name: str = "camera.yaml") -> CameraModel:
    values = _scalars(text)
    camera_type = values.get("Camera.type", "PinHole")
    if camera_type.lower() != "pinhole":
        raise ValueError(f"{name} must use Camera.type PinHole.")
    missing = [f"Camera1.{field}" for field in _INTRINSIC_FIELDS if _intrinsic_key(values, field) is None]
    for key in ("Camera.width", "Camera.height"):
        if key not in values:
            missing.append(key)
    if missing:
        raise ValueError(f"{name} is missing {', '.join(missing)}.")
    chosen = {field: _intrinsic_key(values, field) for field in _INTRINSIC_FIELDS}
    k3_key = _intrinsic_key(values, "k3")
    try:
        model = CameraModel(
            fx=_positive(values, chosen["fx"], name),
            fy=_positive(values, chosen["fy"], name),
            cx=float(values[chosen["cx"]]),
            cy=float(values[chosen["cy"]]),
            k1=float(values[chosen["k1"]]),
            k2=float(values[chosen["k2"]]),
            p1=float(values[chosen["p1"]]),
            p2=float(values[chosen["p2"]]),
            k3=float(values[k3_key]) if k3_key else 0.0,
            width=_positive_int(values, "Camera.width", name),
            height=_positive_int(values, "Camera.height", name),
            fps=_optional_positive(values, "Camera.fps", 30.0),
            rgb=_optional_int(values, "Camera.RGB", 1),
            n_features=_bounded_int(values, "ORBextractor.nFeatures", 1250, 100, 8000),
            scale_factor=_bounded_float(values, "ORBextractor.scaleFactor", 1.2, 1.01, 2.0),
            n_levels=_bounded_int(values, "ORBextractor.nLevels", 8, 1, 16),
            ini_th_fast=_bounded_int(values, "ORBextractor.iniThFAST", 20, 1, 80),
            min_th_fast=_bounded_int(values, "ORBextractor.minThFAST", 7, 1, 80),
        )
    except ValueError as ex:
        if "ORB" in str(ex) or "Camera." in str(ex) or name in str(ex):
            raise
        raise ValueError(f"{name} has a calibration value that is not a number.") from ex
    return model


def newest_yaml(folder: Path) -> Path | None:
    """Most recently written camera file in one folder, or None."""
    if not folder.is_dir():
        return None
    files = [item for item in folder.iterdir() if item.is_file() and item.suffix.lower() in {".yaml", ".yml"}]
    if not files:
        return None
    return max(files, key=lambda item: item.stat().st_mtime)


def _scalars(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or line.startswith("%") or line == "---" or ":" not in line:
            continue
        key, value = line.split(":", 1)
        value = value.strip().strip('"').strip("'")
        if not value or value.startswith("[") or value.startswith("{"):
            continue
        values[key.strip()] = value
    return values


def _positive(values: dict[str, str], key: str, name: str) -> float:
    number = float(values[key])
    if number <= 0:
        raise ValueError(f"{name} has a {key} that must be greater than 0.")
    return number


def _positive_int(values: dict[str, str], key: str, name: str) -> int:
    number = int(round(float(values[key])))
    if number <= 0:
        raise ValueError(f"{name} has a {key} that must be greater than 0.")
    return number


def _optional_positive(values: dict[str, str], key: str, default: float) -> float:
    raw = values.get(key)
    if raw is None:
        return default
    number = float(raw)
    if number <= 0:
        return default
    return number


def _optional_int(values: dict[str, str], key: str, default: int) -> int:
    raw = values.get(key)
    if raw is None:
        return default
    return int(round(float(raw)))


def _bounded_int(values: dict[str, str], key: str, default: int, low: int, high: int) -> int:
    raw = values.get(key)
    if raw is None:
        return default
    number = int(round(float(raw)))
    if number < low or number > high:
        raise ValueError(f"{key} must be from {low} to {high}.")
    return number


def _bounded_float(values: dict[str, str], key: str, default: float, low: float, high: float) -> float:
    raw = values.get(key)
    if raw is None:
        return default
    number = float(raw)
    if number < low or number > high:
        raise ValueError(f"{key} must be from {low} to {high}.")
    return number


def _orb(model: CameraModel, fast_threshold: int):
    return cv2.ORB_create(
        nfeatures=int(model.n_features),
        scaleFactor=float(model.scale_factor),
        nlevels=int(model.n_levels),
        fastThreshold=int(fast_threshold),
    )


def _gray(rgb: np.ndarray) -> np.ndarray | None:
    if rgb is None or getattr(rgb, "ndim", 0) != 3 or rgb.shape[2] != 3:
        return None
    if rgb.dtype != np.uint8:
        return None
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)


def _undistort(keypoints, indexes: list[int], camera: np.ndarray, distortion: np.ndarray) -> np.ndarray:
    points = np.array([keypoints[index].pt for index in indexes], dtype=np.float64).reshape(-1, 1, 2)
    return cv2.undistortPoints(points, camera, distortion, P=camera)


def _check() -> None:
    sample = """%YAML:1.0
---
Camera.type: "PinHole"
Camera1.fx: 921.17
Camera1.fy: 919.02
Camera1.cx: 459.76
Camera1.cy: 351.24
Camera1.k1: -0.0345
Camera1.k2: 0.0707
Camera1.p1: -0.0009
Camera1.p2: 0.0009
Camera.width: 960
Camera.height: 720
Camera.fps: 30.0
Camera.RGB: 1
ORBextractor.nFeatures: 1500
ORBextractor.scaleFactor: 1.2
ORBextractor.nLevels: 8
ORBextractor.iniThFAST: 20
ORBextractor.minThFAST: 7
"""
    model = parse_orb_yaml(sample)
    assert model.fx == 921.17
    assert model.k3 == 0.0
    assert model.width == 960
    assert model.n_features == 1500
    assert model.rgb == 1
    old = parse_orb_yaml(
        "Camera.fx: 900.5\nCamera.fy: 901.25\nCamera.cx: 480\nCamera.cy: 360\n"
        "Camera.k1: -0.1\nCamera.k2: 0.02\nCamera.p1: 0.001\nCamera.p2: -0.002\n"
        "Camera.k3: 0.25\nCamera.width: 960\nCamera.height: 720\n"
    )
    assert old.fx == 900.5 and old.k3 == 0.25
    try:
        parse_orb_yaml('Camera.type: "KannalaBrandt8"\nCamera.fx: 1\n')
    except ValueError as ex:
        assert "PinHole" in str(ex)
    else:
        raise AssertionError("expected a PinHole rejection")

    kind, right, forward = scaled_body_step(0.0, 1.0, 0.0, 40.0, 0.1)
    assert kind == "move" and abs(right) < 1e-9 and abs(forward - 4.0) < 1e-9
    kind, right, _forward = scaled_body_step(1.0, 0.0, 30.0, 0.0, 0.1)
    assert kind == "move" and abs(right - 3.0) < 1e-9
    assert scaled_body_step(0.0, -1.0, 0.0, 40.0, 0.1)[0] == "lost"
    assert scaled_body_step(0.0, 1.0, 0.0, 1.0, 0.1)[0] == "hold"


if __name__ == "__main__":
    _check()
    print("orb track ok")
