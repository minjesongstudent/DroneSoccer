#!/bin/bash
find "$HOME/orbslam3-build/sysroot" -name 'libGLEW*' -o -name 'libGL.so*' -o -name 'libGLU*' | head -40
ls /usr/lib/x86_64-linux-gnu/libGL.so* /usr/lib/x86_64-linux-gnu/libGLU.so* 2>/dev/null || true
