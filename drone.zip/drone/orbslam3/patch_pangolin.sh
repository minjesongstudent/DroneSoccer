#!/bin/bash
set -euo pipefail
file="$HOME/orbslam3-build/Pangolin/src/image/image_io_jpg.cpp"
if ! grep -q cstdint "$file"; then
  sed -i '1i #include <cstdint>' "$file"
fi
echo patched
