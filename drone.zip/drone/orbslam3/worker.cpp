// Headless ORB-SLAM3 monocular server. One grayscale frame in, one pose out.
#include <System.h>

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>

#include <cstdint>
#include <cstring>
#include <iostream>
#include <vector>

namespace {

bool read_full(int fd, void* data, size_t size) {
    auto* bytes = static_cast<unsigned char*>(data);
    size_t got = 0;
    while (got < size) {
        const ssize_t n = ::recv(fd, bytes + got, size - got, 0);
        if (n <= 0) {
            return false;
        }
        got += static_cast<size_t>(n);
    }
    return true;
}

bool write_full(int fd, const void* data, size_t size) {
    auto* bytes = static_cast<const unsigned char*>(data);
    size_t sent = 0;
    while (sent < size) {
        const ssize_t n = ::send(fd, bytes + sent, size - sent, 0);
        if (n <= 0) {
            return false;
        }
        sent += static_cast<size_t>(n);
    }
    return true;
}

void write_pose(int fd, int state, const Sophus::SE3f& pose) {
    const Eigen::Matrix4f matrix = pose.matrix();
    int32_t state_bits = state;
    uint8_t valid = (state == 2 || state == 3 || state == 5) ? 1 : 0;
    double values[16];
    for (int row = 0; row < 4; ++row) {
        for (int col = 0; col < 4; ++col) {
            values[row * 4 + col] = static_cast<double>(matrix(row, col));
        }
    }
    write_full(fd, &state_bits, sizeof(state_bits));
    write_full(fd, &valid, sizeof(valid));
    write_full(fd, values, sizeof(values));
}

}  // namespace

int main(int argc, char** argv) {
    if (argc != 3) {
        std::cerr << "Usage: worker vocabulary settings.yaml\n";
        return 1;
    }

    ORB_SLAM3::Verbose::SetTh(ORB_SLAM3::Verbose::VERBOSITY_QUIET);
    ORB_SLAM3::System slam(argv[1], argv[2], ORB_SLAM3::System::MONOCULAR, false);

    int server = ::socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) {
        std::cerr << "socket failed\n";
        return 1;
    }
    int reuse = 1;
    ::setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(7391);
    if (::bind(server, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0) {
        std::cerr << "bind failed\n";
        return 1;
    }
    if (::listen(server, 1) != 0) {
        std::cerr << "listen failed\n";
        return 1;
    }
    std::cout << "ready 7391" << std::endl;

    const int client = ::accept(server, nullptr, nullptr);
    if (client < 0) {
        std::cerr << "accept failed\n";
        return 1;
    }

    std::vector<unsigned char> pixels;
    while (true) {
        uint8_t kind = 0;
        if (!read_full(client, &kind, sizeof(kind))) {
            break;
        }
        if (kind == 2) {
            slam.Reset();
            int32_t ack = 0;
            write_full(client, &ack, sizeof(ack));
            continue;
        }
        if (kind == 3) {
            break;
        }
        if (kind != 1) {
            break;
        }
        uint32_t width = 0;
        uint32_t height = 0;
        double timestamp = 0.0;
        if (!read_full(client, &width, sizeof(width)) || !read_full(client, &height, sizeof(height)) ||
            !read_full(client, &timestamp, sizeof(timestamp))) {
            break;
        }
        if (width == 0 || height == 0 || width > 4000 || height > 4000) {
            break;
        }
        const size_t count = static_cast<size_t>(width) * static_cast<size_t>(height);
        pixels.resize(count);
        if (!read_full(client, pixels.data(), count)) {
            break;
        }
        cv::Mat image(static_cast<int>(height), static_cast<int>(width), CV_8UC1, pixels.data());
        image = image.clone();
        const Sophus::SE3f pose = slam.TrackMonocular(image, timestamp);
        write_pose(client, slam.GetTrackingState(), pose);
    }

    ::close(client);
    ::close(server);
    slam.Shutdown();
    return 0;
}
