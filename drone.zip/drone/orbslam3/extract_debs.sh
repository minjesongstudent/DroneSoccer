#!/bin/bash
set -euo pipefail
ROOT="$HOME/orbslam3-build"
mkdir -p "$ROOT/sysroot"
cd "$ROOT/debs"
for deb in *.deb; do
  dpkg-deb -x "$deb" "$ROOT/sysroot"
done
find "$ROOT/sysroot/usr/include" \( -name gl.h -o -name glew.h -o -name glu.h \) 
