"""One Tello EDU link: camera, ORB tracking, and a hard room limit.

Flight commands and the camera go through djitellopy. The estimate starts at
(55, 55, 82) cm and yaw 90. The pilot can change that start. X and Y then follow
the forward camera, using an ORB-SLAM3 calibration file. Sticks are cut off at
the field. Mission pads are not used. The field starts at 200 cm on each side.
"""

from __future__ import annotations

import json
import logging
import math
import subprocess
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path

from djitellopy import Tello, TelloException
from djitellopy.tello import BackgroundFrameRead

from geometry import (
    CAGE_CM,
    START_CM,
    START_YAW_DEG,
    AxisScale,
    body_direction_names,
    body_to_world,
    fence_rc,
    flyable_bounds,
    scale_body_speed,
    scale_from_measurement,
    scale_vertical_cm,
    tello_go,
    world_to_body,
    wrap_360,
    x_axis_heading,
    shortest_turn,
)
from orb_track import CameraModel, OrbTracker, load_orb_yaml
from orbslam3_client import OrbSlam3Session, room_step

Tello.LOGGER.setLevel(logging.WARNING)

# get_frame_read waits this long for the first H.264 packet.
LIBRARY_FRAME_WAIT_S = 12
SPEED_NOISE_CM_S = 2.0
STICK_PERIOD_S = 0.05
STICK_SPEED = 35
VERTICAL_NUDGE = 12
VERTICAL_NUDGE_S = 0.30
VERTICAL_RAMP_S = 0.80
GO_SPEED_CM_S = 35
ORB_PERIOD_S = 0.1
LOG_LIMIT = 400


def _install_video_hooks() -> None:
    """Keep the Windows video socket from dropping the Tello stream.

    djitellopy leaves the overrun flags commented out, and its reader only
    catches one PyAV error. Either one ends as a black picture.
    """
    if getattr(BackgroundFrameRead, "_room_hooks", False):
        return

    original_init = BackgroundFrameRead.__init__
    original_update = BackgroundFrameRead.update_frame

    def init(self, tello, address, with_queue=False, maxsize=32):
        if "overrun_nonfatal" not in str(address):
            address = f"{address}?overrun_nonfatal=1&fifo_size=5000"
        self._stream_error = None
        original_init(self, tello, address, with_queue, maxsize)

    def update_frame(self):
        try:
            original_update(self)
        except Exception as ex:
            self._stream_error = ex
            Tello.LOGGER.error("Tello video decode stopped: %s", ex)

    BackgroundFrameRead.__init__ = init  # type: ignore[method-assign]
    BackgroundFrameRead.update_frame = update_frame  # type: ignore[method-assign]
    BackgroundFrameRead._room_hooks = True  # type: ignore[attr-defined]


_install_video_hooks()


@dataclass(frozen=True)
class Snapshot:
    """Copy of the link for the window thread."""

    connected: bool
    connecting: bool
    flying: bool
    busy: bool
    battery: int | None
    x: float
    y: float
    z: float
    yaw: float
    source: str
    calibration: str
    slam3: bool
    start_x: float
    start_y: float
    cage_x: float
    cage_y: float
    cage_z: float
    orb_note: str
    message: str
    fence_holding: bool
    video_note: str
    output_log: tuple[str, ...]
    command_log: tuple[str, ...]


class TelloFlight:
    """Owns the aircraft, the pose estimate, and the stick fence."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._io = threading.Lock()
        self._stop = threading.Event()
        self._drone: Tello | None = None
        self._reader = None
        self._x, self._y, self._z = START_CM
        self._start_x, self._start_y, self._start_z = START_CM
        self._yaw = START_YAW_DEG
        self._yaw_bias = 0.0
        self._yaw_anchor = True
        self._imu_yaw: float | None = None
        self._last_h: float | None = None
        self._h_anchor: float | None = None
        self._z_anchor = START_CM[2]
        self._z_bias = 0.0
        self._z_floor_aligned = False
        self._stamp: float | None = None
        self._camera_model: CameraModel | None = None
        self._calibration_name = ""
        self._tracker = OrbTracker()
        self._tracker_reset = False
        self._slam3 = False
        self._slam_starting = False
        self._slam_scale_cm = 100.0
        self._slam_origin: tuple[float, ...] | None = None
        self._slam_room = (START_CM[0], START_CM[1], START_YAW_DEG)
        self._slam_reanchor = True
        self._slam_session: OrbSlam3Session | None = None
        self._slam_generation = 0
        self._calibration_path: Path | None = None
        self._orb_attempt: float | None = None
        self._orb_note = "Drop an ORB-SLAM3 YAML."
        self._source = "start"
        self._channels = (0, 0, 0, 0)
        self._vertical_is_direction = False
        self._vertical_held_since: float | None = None
        self._sticks_live = False
        self._fence_holding = False
        self._cage = (CAGE_CM, CAGE_CM, CAGE_CM)
        self._bounds = flyable_bounds(self._cage)
        self._scale = load_axis_scale()
        self._measured: dict[str, tuple[float, tuple[str, ...]] | None] = {"x": None, "y": None}
        self._connected = False
        self._connecting = False
        self._busy = False
        self._message = "Join the Tello Wi-Fi, then press Connect."
        self._video_note = "Camera is off."
        self._output_log: deque[str] = deque(maxlen=LOG_LIMIT)
        self._command_log: deque[str] = deque(maxlen=LOG_LIMIT)
        self._last_rc = ""
        self._thread = threading.Thread(target=self._loop, name="tello-flight", daemon=True)
        self._thread.start()

    def snapshot(self) -> Snapshot:
        with self._lock:
            battery = self._battery_unlocked()
            return Snapshot(
                connected=self._connected,
                connecting=self._connecting,
                flying=self._flying_unlocked(),
                busy=self._busy,
                battery=battery,
                x=self._x,
                y=self._y,
                z=self._z,
                yaw=self._yaw,
                source=self._source,
                calibration=self._calibration_name,
                slam3=self._slam3,
                start_x=self._start_x,
                start_y=self._start_y,
                cage_x=self._cage[0],
                cage_y=self._cage[1],
                cage_z=self._cage[2],
                orb_note=self._orb_note,
                message=self._message,
                fence_holding=self._fence_holding,
                video_note=self._video_note,
                output_log=tuple(self._output_log),
                command_log=tuple(self._command_log),
            )

    def copy_frame(self):
        """Latest RGB frame, or None while the decoder is still starting."""
        reader = self._reader
        if reader is None:
            return None
        try:
            frame = reader.frame
        except Exception:
            return None
        if frame is None or getattr(frame, "size", 0) == 0:
            return None
        if frame.shape[0] == 300 and frame.shape[1] == 400 and int(frame.max()) == 0:
            return None
        return frame.copy()

    def connect(self, host: str) -> None:
        host = host.strip()
        if not host:
            with self._lock:
                self._message = "Enter the drone IP address."
            return
        with self._lock:
            if self._connected or self._connecting:
                return
            self._connecting = True
            self._message = f"Connecting to {host}."
        drone = Tello(host)
        drone.TIME_BTW_RC_CONTROL_COMMANDS = STICK_PERIOD_S
        self._watch_commands(drone)
        try:
            with self._io:
                drone.connect()
                self._start_camera(drone)
            with self._lock:
                self._drone = drone
                self._connected = True
                self._message = "Connected."
        except Exception as ex:
            self._stop_camera()
            try:
                drone.end()
            except Exception:
                pass
            with self._lock:
                self._message = f"Connect failed: {ex}"
                self._output_log.append(_log_line(self._message))
            raise
        finally:
            with self._lock:
                self._connecting = False

    def takeoff(self) -> None:
        drone = self._require_idle()
        if drone is None:
            return
        with self._lock:
            self._message = "Taking off."
        try:
            with self._io:
                drone.takeoff()
            with self._lock:
                self._sticks_live = True
                self._z = self._start_z
                self._z_bias = 0.0
                self._z_floor_aligned = False
                self._tracker_reset = True
                self._orb_attempt = None
                if self._camera_model is None:
                    self._message = "Airborne. Drop an ORB-SLAM3 YAML to track the position."
                else:
                    self._message = "Airborne. X and Y are tracking from the start position."
        except Exception as ex:
            text = _takeoff_failure(drone, ex)
            with self._lock:
                self._message = text
                self._output_log.append(_log_line(text))
            raise
        finally:
            with self._lock:
                self._busy = False

    def land(self) -> None:
        """Land where the aircraft is. X and Y stay at the last estimate."""
        with self._lock:
            drone = self._drone
            if drone is None or not self._connected or self._busy:
                return
            if not drone.is_flying:
                self._message = "The aircraft is not flying."
                return
            self._busy = True
            self._sticks_live = False
            self._channels = (0, 0, 0, 0)
            self._message = "Landing."
        try:
            with self._io:
                try:
                    drone.send_rc_control(0, 0, 0, 0)
                except Exception:
                    pass
                drone.land()
            with self._lock:
                self._z = 0.0
                self._z_bias = 0.0
                self._z_floor_aligned = False
                self._tracker_reset = True
                self._orb_attempt = None
                self._source = "landed"
                self._message = "Landed."
        except Exception as ex:
            with self._lock:
                self._message = f"Could not land: {ex}"
                self._output_log.append(_log_line(self._message))
            raise
        finally:
            with self._lock:
                self._busy = False
                drone = self._drone
                if drone is not None and drone.is_flying:
                    self._sticks_live = True

    def _library_go(
        self,
        drone: Tello,
        origin: tuple[float, float, float],
        target: tuple[float, float, float],
        yaw: float,
    ) -> bool:
        """One djitellopy go. False means the move is under the 20 cm minimum.

        The nose turns to +X or -X first, so the room X change is flown forward.
        """
        heading = x_axis_heading(target[0] - origin[0])
        turn = shortest_turn(yaw, heading)
        drone.send_rc_control(0, 0, 0, 0)
        if turn is not None:
            direction, degrees = turn
            if direction == "cw":
                drone.rotate_clockwise(degrees)
            else:
                drone.rotate_counter_clockwise(degrees)
        with self._lock:
            self._yaw = heading
            if self._imu_yaw is not None:
                self._yaw_bias = self._imu_yaw - heading
                self._yaw_anchor = False
            else:
                self._yaw_anchor = True
        packet = tello_go(
            target[0] - origin[0],
            target[1] - origin[1],
            target[2] - origin[2],
            heading,
        )
        if packet is None:
            return False
        drone.send_rc_control(0, 0, 0, 0)
        drone.go_xyz_speed(packet[0], packet[1], packet[2], GO_SPEED_CM_S)
        return True

    def emergency(self) -> None:
        """Cut the motors. The aircraft drops."""
        with self._lock:
            drone = self._drone
            self._sticks_live = False
            self._channels = (0, 0, 0, 0)
        if drone is None:
            return
        try:
            with self._io:
                drone.emergency()
            with self._lock:
                self._message = "Emergency stop. Motors are off."
        except Exception as ex:
            with self._lock:
                self._message = f"Emergency stop failed: {ex}"
                self._output_log.append(_log_line(self._message))

    def set_channels(
        self,
        left_right: int,
        forward: int,
        up_down: int,
        yaw: int,
        vertical_is_direction: bool = False,
    ) -> None:
        """Store the stick. Manual climb passes up/down as -1, 0, or 1."""
        with self._lock:
            self._vertical_is_direction = vertical_is_direction
            self._channels = (
                _clamp(left_right),
                _clamp(forward),
                _clamp(up_down),
                _clamp(yaw),
            )

    def set_pose(self, x: float, y: float, z: float, yaw: float) -> None:
        """Place the estimate at the typed start and begin tracking from there."""
        if not all(math_finite(value) for value in (x, y, z, yaw)):
            raise ValueError("Position and yaw have to be numbers.")
        with self._lock:
            cage = self._cage
        for name, value, limit in (("X", x, cage[0]), ("Y", y, cage[1]), ("Z", z, cage[2])):
            if value < 0 or value > limit:
                raise ValueError(f"{name} has to stay inside 0 to {limit:.0f} cm.")
        yaw = wrap_360(yaw)
        with self._lock:
            self._x, self._y, self._z = float(x), float(y), float(z)
            self._start_x, self._start_y, self._start_z = float(x), float(y), float(z)
            self._yaw = yaw
            if self._imu_yaw is not None:
                self._yaw_bias = self._imu_yaw - yaw
                self._yaw_anchor = False
            else:
                self._yaw_anchor = True
            self._z_anchor = self._z
            self._z_bias = 0.0
            self._z_floor_aligned = False
            self._h_anchor = self._last_h
            self._stamp = None
            self._tracker_reset = True
            self._orb_attempt = None
            self._source = "entered"
            self._message = f"Start position set to {x:.0f}, {y:.0f}, {z:.0f} cm, yaw {yaw:.0f}."

    def set_cage(self, x: float, y: float, z: float) -> None:
        """Field size in centimetres. X is right, Y is forward, Z is up."""
        if not all(math_finite(value) for value in (x, y, z)):
            raise ValueError("Field size has to be numbers.")
        cage = (float(x), float(y), float(z))
        for name, value in (("X", cage[0]), ("Y", cage[1]), ("Z", cage[2])):
            if value < 40 or value > 2000:
                raise ValueError(f"{name} has to be from 40 to 2000 cm.")
        low, high = flyable_bounds(cage)
        if any(high[index] <= low[index] for index in range(3)):
            raise ValueError("The field is smaller than the aircraft.")
        with self._lock:
            self._cage = cage
            self._bounds = (low, high)
            self._message = f"Field size set to {cage[0]:.0f} × {cage[1]:.0f} × {cage[2]:.0f} cm."

    def note(self, text: str) -> None:
        with self._lock:
            self._message = text

    def report(self, text: str) -> None:
        """Keep an error in the output log as well as the status line."""
        with self._lock:
            self._message = text
            self._output_log.append(_log_line(text))

    def load_calibration(self, path: Path) -> None:
        """Read an ORB-SLAM3 PinHole YAML and use it for the next camera frame."""
        path = Path(path)
        if path.suffix.lower() not in {".yaml", ".yml"}:
            raise ValueError("Choose an ORB-SLAM3 .yaml or .yml file.")
        if not path.is_file():
            raise ValueError("That calibration file is not there.")
        self._calibration_path = path
        try:
            model = load_orb_yaml(path)
        except ValueError:
            with self._lock:
                self._camera_model = None
                self._calibration_name = path.name
                self._tracker_reset = True
            raise
        with self._lock:
            self._camera_model = model
            self._calibration_name = path.name
            self._tracker_reset = True
            self._orb_attempt = None
            self._orb_note = "Calibration loaded."
            self._message = (
                f"Loaded {path.name}. fx {model.fx:.1f}, fy {model.fy:.1f}, "
                f"{model.width}x{model.height}."
            )

    def set_slam_scale(self, cm_per_unit: float) -> None:
        """Centimetres represented by one ORB-SLAM3 map unit."""
        if not math_finite(cm_per_unit) or cm_per_unit <= 0 or cm_per_unit > 100000:
            raise ValueError("cm/unit has to be greater than 0.")
        with self._lock:
            self._slam_scale_cm = float(cm_per_unit)

    def set_slam3(self, enabled: bool) -> None:
        """Use ORB-SLAM3 for X, Y, and yaw, or go back to the frame-to-frame tracker."""
        if not enabled:
            with self._lock:
                self._slam_generation += 1
                self._slam3 = False
                self._slam_starting = False
                self._slam_origin = None
                self._slam_reanchor = True
                session = self._slam_session
                self._slam_session = None
                if self._source == "orb-slam3":
                    self._source = "motion"
                self._orb_note = "Frame tracker."
            if session is not None:
                session.close()
            return
        with self._lock:
            path = self._calibration_path
            if path is None:
                raise ValueError("Load an ORB-SLAM3 YAML before turning ORB-SLAM3 on.")
            self._slam_generation += 1
            generation = self._slam_generation
            old = self._slam_session
            self._slam_session = None
            self._slam3 = False
            self._slam_starting = True
            self._slam_origin = None
            self._slam_reanchor = True
            self._orb_note = "ORB-SLAM3 starting."
        if old is not None:
            old.close()
        threading.Thread(
            target=self._start_slam, args=(path, generation), name="orb-slam3", daemon=True
        ).start()

    def _start_slam(self, path: Path, generation: int) -> None:
        session = OrbSlam3Session()
        try:
            session.start(path)
        except Exception as ex:
            with self._lock:
                if generation != self._slam_generation:
                    pass
                else:
                    self._slam3 = False
                    self._slam_starting = False
                    self._orb_note = "ORB-SLAM3 did not start."
                    self._message = str(ex)
                    self._output_log.append(_log_line(str(ex)))
            session.close()
            return
        with self._lock:
            cancelled = generation != self._slam_generation
            old = self._slam_session
            if cancelled:
                pass
            else:
                self._slam_session = session
                self._slam3 = True
                self._slam_starting = False
                self._slam_origin = None
                self._slam_reanchor = True
                self._message = "ORB-SLAM3 is on."
                self._orb_note = "ORB-SLAM3 initializing. Move so the view changes."
        if cancelled:
            session.close()
        elif old is not None:
            old.close()

    def axis_scale(self) -> AxisScale:
        with self._lock:
            return self._scale

    def set_axis_scale(self, scale: AxisScale) -> None:
        """Remember how far each body direction really travels."""
        for name in ("forward", "back", "left", "right", "up", "down"):
            value = float(getattr(scale, name))
            if value <= 0 or value > 500:
                raise ValueError(f"{name} correction has to be between 0 and 500.")
        with self._lock:
            self._scale = scale
            self._message = "Axis corrections saved."
        save_axis_scale(scale)

    def go_to(self, x: float, y: float, z: float) -> None:
        """Fly to a room position with one library go command."""
        with self._lock:
            cage = self._cage
        for name, value, limit in (("X", x, cage[0]), ("Y", y, cage[1]), ("Z", z, cage[2])):
            if not math_finite(value) or value < 0 or value > limit:
                raise ValueError(f"{name} has to stay inside 0 to {limit:.0f} cm.")
        with self._lock:
            drone = self._drone
            if drone is None or not self._connected:
                self._message = "Press Connect before moving."
                return
            if not drone.is_flying:
                self._message = "Take off before moving to a position."
                return
            if self._busy:
                return
            self._busy = True
            self._sticks_live = False
            self._channels = (0, 0, 0, 0)
            yaw = self._yaw
            origin = (self._x, self._y, self._z)
            low, high = self._bounds
        target = tuple(min(high[index], max(low[index], float(value))) for index, value in enumerate((x, y, z)))
        limited = any(abs(target[index] - float((x, y, z)[index])) > 0.5 for index in range(3))
        face = "+X" if target[0] >= origin[0] else "-X"
        with self._lock:
            self._message = (
                f"Facing {face}, flying to {target[0]:.0f}, {target[1]:.0f}, {target[2]:.0f}."
                + (" The body limit shortened it." if limited else "")
            )
        try:
            with self._io:
                if not self._library_go(drone, origin, target, yaw):
                    with self._lock:
                        self._message = "That move is too small."
                    return
            with self._lock:
                self._x, self._y, self._z = target
                self._z_anchor = self._z
                self._h_anchor = self._last_h
                self._stamp = None
                self._message = f"Arrived near {target[0]:.0f}, {target[1]:.0f}, {target[2]:.0f}."
        except Exception as ex:
            with self._lock:
                self._message = f"Move failed: {ex}"
                self._output_log.append(_log_line(self._message))
            raise
        finally:
            with self._lock:
                self._busy = False
                self._tracker_reset = True
                self._orb_attempt = None
                drone = self._drone
                if drone is not None and drone.is_flying:
                    self._sticks_live = True

    def move_axis(self, axis: str, distance_cm: float) -> None:
        """Fly one room axis. X is right, Y is forward. Z stays put."""
        if axis not in ("x", "y"):
            raise ValueError("Choose X or Y.")
        if not math_finite(distance_cm) or abs(distance_cm) < 20 or abs(distance_cm) > 500:
            raise ValueError("Enter a move from 20 to 500 cm.")
        with self._lock:
            drone = self._drone
            if drone is None or not self._connected:
                self._message = "Press Connect before moving."
                return
            if not drone.is_flying:
                self._message = "Take off before moving."
                return
            if self._busy:
                return
            yaw = self._yaw
            origin = (self._x, self._y, self._z)
            low, high = self._bounds
            dx = float(distance_cm) if axis == "x" else 0.0
            dy = float(distance_cm) if axis == "y" else 0.0
            target = (origin[0] + dx, origin[1] + dy, origin[2])
            if any(target[index] < low[index] or target[index] > high[index] for index in range(3)):
                self._message = "That move would leave the flyable room."
                return
            right, forward = world_to_body(dx, dy, yaw)
            names = body_direction_names(right, forward)
            if not names:
                self._message = "That move is too small."
                return
            self._busy = True
            self._sticks_live = False
            self._channels = (0, 0, 0, 0)
            self._message = f"Moving {distance_cm:.0f} cm on {axis.upper()}."
        try:
            with self._io:
                if not self._library_go(drone, origin, target, yaw):
                    with self._lock:
                        self._message = "That move is too small."
                    return
            with self._lock:
                self._x, self._y, self._z = target
                self._z_anchor = self._z
                self._h_anchor = self._last_h
                self._stamp = None
                self._measured[axis] = (float(distance_cm), names)
                self._message = (
                    f"Moved {distance_cm:.0f} cm on {axis.upper()}. "
                    "Type the actual centimetres, then Save."
                )
        except Exception as ex:
            with self._lock:
                self._message = f"Move failed: {ex}"
                self._output_log.append(_log_line(self._message))
            raise
        finally:
            with self._lock:
                self._busy = False
                self._tracker_reset = True
                self._orb_attempt = None
                drone = self._drone
                if drone is not None and drone.is_flying:
                    self._sticks_live = True

    def save_axis_measurement(self, axis: str, actual_cm: float) -> None:
        """Turn a measured X or Y move into the correction for the nose directions it used."""
        if axis not in ("x", "y"):
            raise ValueError("Choose X or Y.")
        if not math_finite(actual_cm):
            raise ValueError("Enter the actual centimetres as a number.")
        with self._lock:
            recorded = self._measured.get(axis)
            scale = self._scale
        if recorded is None:
            raise ValueError(f"Move on {axis.upper()} before saving the actual distance.")
        desired, names = recorded
        updated = scale_from_measurement(scale, names, desired, actual_cm)
        self.set_axis_scale(updated)
        detail = ", ".join(f"{name} {getattr(updated, name):.0f}" for name in names)
        with self._lock:
            self._message = (
                f"Correction saved from the {desired:.0f} cm {axis.upper()} move. "
                f"Now {detail} cm per 100."
            )

    def shutdown(self) -> None:
        self._stop.set()
        with self._lock:
            session = self._slam_session
            self._slam_session = None
            self._slam3 = False
            self._slam_starting = False
        if session is not None:
            session.close()
        with self._lock:
            drone = self._drone
            self._sticks_live = False
            self._channels = (0, 0, 0, 0)
        if drone is None:
            return
        try:
            with self._io:
                try:
                    drone.send_rc_control(0, 0, 0, 0)
                except Exception:
                    pass
                if drone.is_flying:
                    drone.land()
        except Exception:
            pass
        self._stop_camera()
        try:
            drone.end()
        except Exception:
            pass

    def _loop(self) -> None:
        while not self._stop.is_set():
            try:
                self._poll()
                self._send_stick()
            except Exception as ex:
                text = f"Link error: {ex}"
                with self._lock:
                    if self._message != text:
                        self._message = text
                        self._output_log.append(_log_line(text))
                self._stop.wait(0.3)
                continue
            self._stop.wait(STICK_PERIOD_S)

    def _poll(self) -> None:
        with self._lock:
            drone = self._drone
            connected = self._connected
            model = self._camera_model
            reset = self._tracker_reset
            busy = self._busy
            if reset:
                self._tracker_reset = False
        if drone is None or not connected:
            return
        if reset:
            if model is not None and not self._tracker.accepts(model):
                try:
                    self._tracker.configure(model)
                except Exception:
                    with self._lock:
                        self._orb_note = "Calibration could not start."
            else:
                self._tracker.reset()
            with self._lock:
                self._slam_origin = None
                self._slam_reanchor = True
                slam_session = self._slam_session if self._slam3 else None
            if slam_session is not None:
                try:
                    slam_session.reset()
                except Exception as ex:
                    self.report(str(ex))
        try:
            state = dict(drone.get_current_state())
        except Exception:
            return
        now = time.perf_counter()
        height = _optional_float(state.get("h"))
        floor_cm = _floor_distance_cm(state.get("tof"))
        imu = _optional_float(state.get("yaw"))
        with self._lock:
            self._track_yaw(imu)
            if height is not None:
                self._last_h = height
            flying = self._flying_unlocked()
            slam3 = self._slam3
            slam_starting = self._slam_starting
            slam_session = self._slam_session
        tracked = False
        if slam3 or slam_starting:
            # ORB-SLAM3 owns X and Y. Speed is not added on top of the map.
            tracked = True
            if slam3 and slam_session is not None and model is not None:
                self._feed_slam(slam_session, model, now, flying and not busy)
        elif model is not None and flying and not busy:
            tracked = self._try_orb(state, now)

        with self._lock:
            flying = self._flying_unlocked()
            # A Go command adds the corrected distance itself. Integrating speed
            # during that command would count the same move twice.
            if flying and not self._busy and not tracked:
                if self._stamp is not None:
                    dt = now - self._stamp
                    if 0 < dt <= 0.5:
                        self._integrate(state, dt)
                self._source = "motion"
            self._stamp = now
            if flying:
                self._apply_z(floor_cm, height)

    def _track_yaw(self, imu: float | None) -> None:
        if imu is None:
            return
        self._imu_yaw = imu
        if self._slam3 and self._slam_origin is not None and not self._slam_reanchor:
            return
        if self._yaw_anchor:
            self._yaw_bias = imu - self._yaw
            self._yaw_anchor = False
            return
        self._yaw = wrap_360(imu - self._yaw_bias)

    def _feed_slam(self, session: OrbSlam3Session, model: CameraModel, now: float, apply: bool) -> None:
        """Send the latest frame to ORB-SLAM3 and, when tracking, move X, Y, and yaw."""
        frame = self.copy_frame()
        if frame is None:
            return
        try:
            state, pose = session.track(frame, now, model.width, model.height)
        except Exception as ex:
            self.report(str(ex))
            with self._lock:
                self._orb_note = "ORB-SLAM3 stopped."
                self._source = "orb-slam3"
            return
        with self._lock:
            self._source = "orb-slam3"
            if pose is None:
                self._slam_reanchor = True
                if state in (0, 1):
                    self._orb_note = "ORB-SLAM3 initializing. Move so the view changes."
                else:
                    self._orb_note = "ORB-SLAM3 lost."
                return
            if not apply:
                self._slam_reanchor = True
                self._orb_note = "ORB-SLAM3 tracking."
                return
            if self._slam_reanchor or self._slam_origin is None:
                self._slam_origin = pose
                self._slam_room = (self._x, self._y, self._yaw)
                self._slam_reanchor = False
                self._orb_note = "ORB-SLAM3 tracking."
                return
            right, forward, yaw_delta = room_step(self._slam_origin, pose, self._slam_scale_cm)
            x0, y0, yaw0 = self._slam_room
            world_x, world_y = body_to_world(right, forward, yaw0)
            self._x = x0 + world_x
            self._y = y0 + world_y
            self._yaw = wrap_360(yaw0 + yaw_delta)
            self._orb_note = "ORB-SLAM3 tracking."

    def _try_orb(self, state: dict, now: float) -> bool:
        """Update X and Y from the camera. True means this poll should not also integrate speed."""
        with self._lock:
            last = self._orb_attempt
            if last is not None and now - last < ORB_PERIOD_S:
                return True
            self._orb_attempt = now
            dt = ORB_PERIOD_S if last is None else min(0.5, now - last)
            yaw = self._yaw
            scale = self._scale
        frame = self.copy_frame()
        if frame is None:
            with self._lock:
                self._orb_attempt = last
            return False
        vgx = _optional_float(state.get("vgx")) or 0.0
        vgy = _optional_float(state.get("vgy")) or 0.0
        if abs(vgx) < SPEED_NOISE_CM_S:
            vgx = 0.0
        if abs(vgy) < SPEED_NOISE_CM_S:
            vgy = 0.0
        right, forward = scale_body_speed(vgx, vgy, scale)
        try:
            step = self._tracker.track(frame, dt, right, forward)
        except Exception:
            with self._lock:
                self._orb_note = "ORB tracking failed."
            return False
        with self._lock:
            self._orb_note = self._tracker.note
            if self._busy:
                return True
            if step.kind == "lost":
                if 0 < dt <= 0.5:
                    self._integrate(state, dt)
                self._source = "motion"
                return True
            if step.kind == "move":
                world_x, world_y = body_to_world(step.right_cm, step.forward_cm, yaw)
                self._x += world_x
                self._y += world_y
            self._source = "orb"
            return True

    def _integrate(self, state: dict, dt: float) -> None:
        vgx = _optional_float(state.get("vgx")) or 0.0
        vgy = _optional_float(state.get("vgy")) or 0.0
        if abs(vgx) < SPEED_NOISE_CM_S:
            vgx = 0.0
        if abs(vgy) < SPEED_NOISE_CM_S:
            vgy = 0.0
        right_speed, forward_speed = scale_body_speed(vgx, vgy, self._scale)
        world_x, world_y = body_to_world(right_speed, forward_speed, self._yaw)
        self._x += world_x * dt
        self._y += world_y * dt

    def _apply_z(self, floor_cm: float | None, baro_cm: float | None) -> None:
        """Keep height on the floor sensor, shifted so the start Z stays the origin.

        The first reading after takeoff or Set start lines up with the typed Z.
        Later readings move Z by the same amount the floor distance moved.
        """
        if floor_cm is not None:
            if not self._z_floor_aligned:
                self._z_bias = self._z - floor_cm
                self._z_floor_aligned = True
            self._z = floor_cm + self._z_bias
            self._z_anchor = self._z
            if baro_cm is not None:
                self._h_anchor = baro_cm
            return
        self._follow_height(baro_cm)

    def _follow_height(self, height: float | None) -> None:
        if height is None:
            return
        if self._h_anchor is None:
            self._h_anchor = height
            self._z_anchor = self._z
            return
        delta = height - self._h_anchor
        if abs(delta) > 200:
            return
        self._z = self._z_anchor + scale_vertical_cm(delta, self._scale)

    def _watch_commands(self, drone: Tello) -> None:
        """Copy each SDK packet into the command log, and failures into output."""
        original_return = drone.send_command_with_return
        original_blind = drone.send_command_without_return

        def send_command_with_return(command: str, timeout: int = Tello.RESPONSE_TIMEOUT) -> str:
            self._record_command(f"> {command}")
            try:
                response = original_return(command, timeout=timeout)
            except Exception as ex:
                self._record_command(f"< {ex}")
                self._record_output(f"{command}: {ex}")
                raise
            text = str(response)
            self._record_command(f"< {text}")
            if "ok" not in text.lower():
                self._record_output(f"{command}: {text}")
            return response

        def send_command_without_return(command: str) -> None:
            if command.startswith("rc "):
                with self._lock:
                    changed = command != self._last_rc
                    self._last_rc = command
                if changed:
                    self._record_command(f"> {command}")
            else:
                self._record_command(f"> {command}")
            return original_blind(command)

        drone.send_command_with_return = send_command_with_return  # type: ignore[method-assign]
        drone.send_command_without_return = send_command_without_return  # type: ignore[method-assign]

    def _record_command(self, text: str) -> None:
        with self._lock:
            self._command_log.append(_log_line(text))

    def _record_output(self, text: str) -> None:
        with self._lock:
            self._output_log.append(_log_line(text))

    def clear_output(self) -> None:
        with self._lock:
            self._output_log.clear()

    def clear_commands(self) -> None:
        with self._lock:
            self._command_log.clear()
            self._last_rc = ""

    def _send_stick(self) -> None:
        with self._lock:
            if not self._sticks_live or self._busy:
                self._fence_holding = False
                return
            drone = self._drone
            channels = self._channels
            yaw = self._yaw
            position = (self._x, self._y, self._z)
            bounds = self._bounds
            flying = self._flying_unlocked()
        if drone is None or not flying:
            return
        left_right, forward, up_down, yaw_rate = channels
        up_down = self._vertical_rc(up_down)
        left_right, forward, up_down, held = fence_rc(
            left_right,
            forward,
            up_down,
            yaw,
            position,
            bounds,
        )
        with self._io:
            with self._lock:
                if not self._sticks_live or self._busy or self._drone is not drone:
                    return
                self._fence_holding = held
            drone.send_rc_control(left_right, forward, up_down, yaw_rate)

    def _vertical_rc(self, vertical: int) -> int:
        """A short climb stays slow. Holding W or S ramps up to the stick speed."""
        if not self._vertical_is_direction:
            self._vertical_held_since = None
            return _clamp(vertical)
        if vertical == 0:
            self._vertical_held_since = None
            return 0
        now = time.perf_counter()
        if self._vertical_held_since is None:
            self._vertical_held_since = now
        held = now - self._vertical_held_since
        full = max(VERTICAL_NUDGE, STICK_SPEED)
        if held <= VERTICAL_NUDGE_S:
            magnitude = VERTICAL_NUDGE
        else:
            blend = min(1.0, (held - VERTICAL_NUDGE_S) / VERTICAL_RAMP_S)
            magnitude = VERTICAL_NUDGE + (full - VERTICAL_NUDGE) * blend
        sign = 1 if vertical > 0 else -1
        return sign * int(round(magnitude))

    def _start_camera(self, drone: Tello) -> None:
        self._stop_camera()
        Tello.FRAME_GRAB_TIMEOUT = LIBRARY_FRAME_WAIT_S
        drone.background_frame_read = None
        box: dict = {}

        def open_reader() -> None:
            try:
                box["reader"] = drone.get_frame_read()
            except Exception as ex:
                box["error"] = ex

        port = int(drone.vs_udp_port)
        opener = threading.Thread(target=open_reader, name="tello-camera", daemon=True)
        opener.start()
        if not _wait_for_udp(port, 3.0):
            with self._lock:
                self._video_note = f"Camera port {port} did not open."
                self._output_log.append(_log_line(self._video_note))
        try:
            drone.streamon()
        except TelloException as ex:
            with self._lock:
                self._video_note = f"streamon failed: {ex}"
                self._output_log.append(_log_line(self._video_note))
            opener.join(timeout=1.0)
            return
        opener.join(timeout=LIBRARY_FRAME_WAIT_S + 2)
        reader = box.get("reader")
        if reader is None:
            with self._lock:
                self._video_note = f"Camera failed: {box.get('error', 'timed out')}"
                self._output_log.append(_log_line(self._video_note))
            return
        self._reader = reader
        with self._lock:
            self._video_note = "Waiting for the camera."

    def _stop_camera(self) -> None:
        reader = self._reader
        self._reader = None
        if reader is None:
            return
        try:
            reader.stop()
        except Exception:
            pass

    def _require_idle(self) -> Tello | None:
        with self._lock:
            drone = self._drone
            if drone is None or not self._connected:
                self._message = "Takeoff was not sent. Press Connect before takeoff."
                self._output_log.append(_log_line(self._message))
                self._command_log.append(_log_line("> takeoff"))
                self._command_log.append(_log_line("< not sent"))
                return None
            if self._busy or drone.is_flying:
                self._message = "Takeoff was not sent. The aircraft is already busy."
                self._output_log.append(_log_line(self._message))
                self._command_log.append(_log_line("> takeoff"))
                self._command_log.append(_log_line("< not sent"))
                return None
            self._busy = True
            self._sticks_live = False
            return drone

    def _flying_unlocked(self) -> bool:
        drone = self._drone
        return bool(drone is not None and drone.is_flying)

    def _battery_unlocked(self) -> int | None:
        drone = self._drone
        if drone is None or not self._connected:
            return None
        try:
            state = drone.get_current_state()
        except Exception:
            return None
        battery = _optional_float(state.get("bat"))
        if battery is None:
            return None
        return int(battery)


def load_axis_scale() -> AxisScale:
    """Last saved per-direction corrections. Missing file means no correction."""
    try:
        payload = json.loads(_axis_scale_path().read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return AxisScale()
    if not isinstance(payload, dict):
        return AxisScale()
    values = []
    for name in ("forward", "back", "left", "right", "up", "down"):
        try:
            value = float(payload.get(name, 100))
        except (TypeError, ValueError):
            value = 100.0
        if value <= 0 or value > 500:
            value = 100.0
        values.append(value)
    return AxisScale(*values)


def save_axis_scale(scale: AxisScale) -> None:
    payload = {
        "forward": scale.forward,
        "back": scale.back,
        "left": scale.left,
        "right": scale.right,
        "up": scale.up,
        "down": scale.down,
    }
    _axis_scale_path().write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def _axis_scale_path() -> Path:
    return Path(__file__).resolve().parent / "axis_scale.json"


def _floor_distance_cm(value: object) -> float | None:
    """Downward range in centimetres, or None when the reading is not usable."""
    distance = _optional_float(value)
    if distance is None or distance < 8.0 or distance > 400.0:
        return None
    return distance


def _optional_float(value: object) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value)


def math_finite(value: float) -> bool:
    return value == value and value not in (float("inf"), float("-inf"))


def _log_line(text: str) -> str:
    return f"{time.strftime('%H:%M:%S')}  {text}"


def _takeoff_failure(drone: Tello, error: Exception) -> str:
    """Add the state packet to a takeoff refusal. error alone does not say why."""
    try:
        state = drone.get_current_state() or {}
    except Exception:
        state = {}
    parts: list[str] = []
    battery = state.get("bat")
    pitch = state.get("pitch")
    roll = state.get("roll")
    tof = state.get("tof")
    if battery is not None:
        parts.append(f"battery {battery}%")
    if pitch is not None and roll is not None:
        parts.append(f"pitch {pitch} roll {roll}")
    if tof is not None:
        parts.append(f"tof {tof} cm")
    detail = f" {', '.join(parts)}." if parts else ""
    return f"Takeoff failed: {error}.{detail}"


def _clamp(value: int) -> int:
    return max(-100, min(100, int(value)))


def _wait_for_udp(port: int, seconds: float) -> bool:
    deadline = time.perf_counter() + seconds
    while time.perf_counter() < deadline:
        if _udp_open(port):
            return True
        time.sleep(0.05)
    return _udp_open(port)


def _udp_open(port: int) -> bool:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        output = subprocess.check_output(
            ["netstat", "-ano", "-p", "udp"],
            stderr=subprocess.DEVNULL,
            text=True,
            creationflags=flags,
        )
    except (OSError, subprocess.CalledProcessError):
        return False
    token = f":{port}"
    for line in output.splitlines():
        parts = line.split()
        if len(parts) >= 2 and parts[0].upper() == "UDP" and parts[1].endswith(token):
            return True
    return False

