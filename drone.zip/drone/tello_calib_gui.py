import cv2
import numpy as np
import time
import threading
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from djitellopy import Tello

CAPTURE_DIR = Path(__file__).resolve().parent / "calib_captures"

class TelloCalibratorUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Tello Camera Calibration for ORB-SLAM3")
        self.root.geometry("1060x830")

        self.samples = []
        self.capture_dir = CAPTURE_DIR

        self.tello = None
        self.frame_read = None
        self.running = False

        # Status & Threading
        self.telemetry_thread = None
        self.lock = threading.Lock()
        self.current_battery = -1
        self.current_temp = -1
        self.is_connected = False
        # djitellopy keeps the last state dict forever. Identity changes only
        # when a new UDP state packet arrives.
        self._seen_state = None

        self.current_corners = None
        self.current_frame = None
        self.current_gray = None
        self.img_size = None

        self.create_widgets()
        self._load_saved_captures()

    def create_widgets(self):
        # Section 1: Settings & Telemetry
        top_frame = ttk.LabelFrame(self.root, text=" 1. Tello Connection, Telemetry & Checkerboard Settings ")
        top_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(top_frame, text="Total Squares (W x H):").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.squares_entry = ttk.Entry(top_frame, width=8)
        self.squares_entry.insert(0, "9x7")  # 9x7 squares -> 8x6 internal corners
        self.squares_entry.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(top_frame, text="Square Size (cm):").grid(row=0, column=2, padx=5, pady=5, sticky="w")
        self.size_cm_entry = ttk.Entry(top_frame, width=8)
        self.size_cm_entry.insert(0, "2.7")  # 2.7 cm
        self.size_cm_entry.grid(row=0, column=3, padx=5, pady=5)

        self.btn_connect = ttk.Button(top_frame, text="Connect Tello Stream", command=self.toggle_stream)
        self.btn_connect.grid(row=0, column=4, padx=15, pady=5)

        # Real-time Telemetry Dashboard (Status, Battery, Temperature)
        telemetry_frame = ttk.Frame(top_frame)
        telemetry_frame.grid(row=1, column=0, columnspan=5, padx=5, pady=6, sticky="w")

        self.lbl_status_badge = tk.Label(telemetry_frame, text="[DISCONNECTED]", fg="white", bg="#777777", font=("Arial", 9, "bold"), padx=6, pady=2)
        self.lbl_status_badge.pack(side="left", padx=5)

        self.lbl_battery_badge = tk.Label(telemetry_frame, text="Battery: --%", fg="black", bg="#e0e0e0", font=("Arial", 9, "bold"), padx=6, pady=2)
        self.lbl_battery_badge.pack(side="left", padx=5)

        self.lbl_temp_badge = tk.Label(telemetry_frame, text="Temp: --°C", fg="black", bg="#e0e0e0", font=("Arial", 9, "bold"), padx=6, pady=2)
        self.lbl_temp_badge.pack(side="left", padx=5)

        self.lbl_diagnostic = ttk.Label(telemetry_frame, text="Waiting for drone connection...", font=("Arial", 9))
        self.lbl_diagnostic.pack(side="left", padx=10)

        # Center: Live Video Feed
        self.video_label = ttk.Label(self.root)
        self.video_label.pack(expand=True, fill="both", padx=10, pady=5)

        # Section 2: Controls & Actions
        bottom_frame = ttk.LabelFrame(self.root, text=" 2. Capture & Calibration ")
        bottom_frame.pack(fill="x", padx=10, pady=5)

        self.btn_capture = ttk.Button(
            bottom_frame, 
            text="📷 Capture Frame (Spacebar)", 
            command=self.capture_frame, 
            state="disabled"
        )
        self.btn_capture.pack(side="left", padx=10, pady=8)

        self.btn_calc = ttk.Button(
            bottom_frame, 
            text="💾 Calibrate & Export ORB-SLAM3 YAML", 
            command=self.calibrate_and_save, 
            state="disabled"
        )
        self.btn_calc.pack(side="left", padx=10, pady=8)

        self.lbl_sample_count = ttk.Label(
            bottom_frame, 
            text="Captured Frames: 0 (saved in calib_captures/, recommended 15~25)", 
            font=("Arial", 10, "bold")
        )
        self.lbl_sample_count.pack(side="right", padx=15, pady=8)

        # Instance binding runs before the TButton class binding, so Space
        # captures a frame instead of activating the focused button.
        self._bind_space_capture(self.root)

    def _on_space(self, event):
        self.capture_frame()
        return "break"

    def _bind_space_capture(self, widget):
        widget.bind("<space>", self._on_space)
        for child in widget.winfo_children():
            self._bind_space_capture(child)

    def get_corner_dimensions(self):
        try:
            sq_w, sq_h = map(int, self.squares_entry.get().lower().split('x'))
            if sq_w <= 1 or sq_h <= 1:
                return (8, 6)
            return (sq_w - 1, sq_h - 1)
        except Exception:
            return (8, 6)

    def _read_fresh_telemetry(self):
        """Battery and temperature from a state packet that just arrived.

        get_battery() only reads djitellopy's cached dict, so a drone that
        already left still looks connected.
        """
        state = self.tello.get_current_state()
        if not state or state is self._seen_state:
            raise RuntimeError("No new state packet from Tello")

        batt = int(state["bat"])
        temp = (float(state["templ"]) + float(state["temph"])) / 2
        self._seen_state = state
        return batt, temp

    def _telemetry_worker(self):
        """Monitors connection health, battery level, and temperature every 3 seconds"""
        fail_count = 0
        while self.running:
            try:
                if self.tello:
                    batt, temp = self._read_fresh_telemetry()

                    self.current_battery = batt
                    self.current_temp = temp
                    self.is_connected = True
                    fail_count = 0

                    self.root.after(0, self.update_telemetry_ui, batt, temp, True, "")
            except Exception:
                fail_count += 1
                if fail_count >= 2:
                    self.is_connected = False
                    err_msg = "Lost response from Tello. Wi-Fi disconnected or auto-shutdown."
                    self.root.after(0, self.update_telemetry_ui, -1, -1, False, err_msg)

            time.sleep(3.0)

    def update_telemetry_ui(self, batt, temp, connected, err_msg):
        if not self.running:
            return

        if not connected:
            self.lbl_status_badge.config(text="[DISCONNECTED]", bg="#cc0000", fg="white")
            self.lbl_battery_badge.config(text="Battery: --%", bg="#e0e0e0", fg="black")
            self.lbl_temp_badge.config(text="Temp: --°C", bg="#e0e0e0", fg="black")
            self.lbl_diagnostic.config(text=f"⚠️ {err_msg}", foreground="#cc0000")
            return

        # Status Badge
        self.lbl_status_badge.config(text="[CONNECTED]", bg="#2e7d32", fg="white")

        # Battery Badge
        if batt <= 15:
            self.lbl_battery_badge.config(text=f"Battery: {batt}% [CRITICAL]", bg="#d32f2f", fg="white")
        elif batt <= 30:
            self.lbl_battery_badge.config(text=f"Battery: {batt}% [LOW]", bg="#f57c00", fg="white")
        else:
            self.lbl_battery_badge.config(text=f"Battery: {batt}%", bg="#388e3c", fg="white")

        # Temperature Badge (Tello shuts down automatically at ~85-90°C)
        if temp >= 82:
            self.lbl_temp_badge.config(text=f"Temp: {temp}°C [OVERHEAT RISK]", bg="#d32f2f", fg="white")
        elif temp >= 75:
            self.lbl_temp_badge.config(text=f"Temp: {temp}°C [WARM]", bg="#f57c00", fg="white")
        else:
            self.lbl_temp_badge.config(text=f"Temp: {temp}°C", bg="#388e3c", fg="white")

        # Diagnostic messages
        warnings = []
        if batt <= 20:
            warnings.append("Low Battery (Recharge soon)")
        if temp >= 80:
            warnings.append("High Temperature (Cool down drone with a fan)")

        if warnings:
            self.lbl_diagnostic.config(text=" | ".join(warnings), foreground="#d32f2f")
        else:
            self.lbl_diagnostic.config(text="Status normal. Ready to capture.", foreground="#2e7d32")

    def toggle_stream(self):
        if not self.running:
            try:
                self.tello = Tello()
                self.tello.connect()
                battery_text = str(self.tello.send_command_with_return("battery?", timeout=3)).strip()
                if not battery_text.isdigit():
                    raise RuntimeError(
                        "Tello did not answer a battery query. "
                        "The drone is not connected."
                    )

                self.tello.streamon()
                time.sleep(1.0)
                self.frame_read = self.tello.get_frame_read()

                self._seen_state = None
                self.running = True

                # Start telemetry background thread
                self.telemetry_thread = threading.Thread(target=self._telemetry_worker, daemon=True)
                self.telemetry_thread.start()

                self.btn_connect.config(text="Disconnect Tello")
                self.btn_capture.config(state="normal")
                self.btn_calc.config(state="normal")
                self.update_video()

            except Exception as e:
                messagebox.showerror(
                    "Connection Error", 
                    f"Failed to connect to Tello:\n{e}\n\n"
                    f"Troubleshooting checklist:\n"
                    f"1. Is PC connected to Tello Wi-Fi?\n"
                    f"2. Is the drone battery charged?\n"
                    f"3. Has the drone cooled down from previous runs?"
                )
                if self.tello:
                    try:
                        self.tello.end()
                    except:
                        pass
        else:
            self.running = False
            if self.tello:
                try:
                    self.tello.streamoff()
                    self.tello.end()
                except:
                    pass
            self._seen_state = None
            self.is_connected = False
            self.btn_connect.config(text="Connect Tello Stream")
            self.btn_capture.config(state="disabled")
            self.lbl_status_badge.config(text="[DISCONNECTED]", bg="#777777", fg="white")
            self.lbl_battery_badge.config(text="Battery: --%", bg="#e0e0e0", fg="black")
            self.lbl_temp_badge.config(text="Temp: --°C", bg="#e0e0e0", fg="black")
            self.lbl_diagnostic.config(text="Stream stopped by user.", foreground="black")

    def update_video(self):
        if not self.running or self.frame_read is None:
            return

        frame = self.frame_read.frame
        if frame is not None and frame.size > 0:
            self.current_frame = frame.copy()
            display_img = self.current_frame.copy()
            self.current_gray = cv2.cvtColor(self.current_frame, cv2.COLOR_BGR2GRAY)
            self.img_size = (self.current_gray.shape[1], self.current_gray.shape[0])

            board_corners = self.get_corner_dimensions()

            # Find corners
            found, corners = cv2.findChessboardCorners(
                self.current_gray, board_corners,
                cv2.CALIB_CB_ADAPTIVE_THRESH + cv2.CALIB_CB_FAST_CHECK + cv2.CALIB_CB_NORMALIZE_IMAGE
            )

            if found:
                self.current_corners = cv2.cornerSubPix(
                    self.current_gray, corners, (11, 11), (-1, -1),
                    (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001)
                )
                cv2.drawChessboardCorners(display_img, board_corners, self.current_corners, found)
                cv2.putText(
                    display_img, 
                    f"STATUS: Pattern Found ({board_corners[0]}x{board_corners[1]})! [Space to Capture]", 
                    (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2
                )
            else:
                self.current_corners = None
                cv2.putText(
                    display_img, 
                    f"STATUS: Searching for {board_corners[0]}x{board_corners[1]} corners...", 
                    (20, 35), cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 0, 255), 2
                )

            # Fit in UI window
            rgb_img = cv2.cvtColor(display_img, cv2.COLOR_BGR2RGB)
            h, w = rgb_img.shape[:2]
            scale = min(960 / w, 540 / h)
            resized = cv2.resize(rgb_img, (int(w * scale), int(h * scale)))

            img_tk = ImageTk.PhotoImage(image=Image.fromarray(resized))
            self.video_label.imgtk = img_tk
            self.video_label.configure(image=img_tk)

        self.root.after(30, self.update_video)

    def _square_size_m(self):
        try:
            return float(self.size_cm_entry.get()) * 0.01
        except ValueError:
            return 0.027

    def _refresh_sample_label(self):
        count = len(self.samples)
        self.lbl_sample_count.config(
            text=f"Captured Frames: {count} (saved in calib_captures/, recommended 15~25)"
        )

    def _next_capture_id(self):
        ids = [int(path.stem) for path in self.capture_dir.glob("*.png") if path.stem.isdigit()]
        return max(ids, default=0) + 1

    def _load_saved_captures(self):
        self.capture_dir.mkdir(parents=True, exist_ok=True)
        loaded = []
        for png_path in sorted(self.capture_dir.glob("*.png")):
            npz_path = png_path.with_suffix(".npz")
            if not npz_path.exists():
                continue
            try:
                data = np.load(str(npz_path))
                loaded.append({
                    "corners": np.asarray(data["corners"], dtype=np.float32),
                    "board_w": int(data["board_w"]),
                    "board_h": int(data["board_h"]),
                    "image_size": (int(data["image_w"]), int(data["image_h"])),
                })
            except Exception as e:
                print(f"[Capture] Skipping {npz_path.name}: {e}")

        with self.lock:
            self.samples = loaded
        self._refresh_sample_label()
        if loaded:
            self.btn_calc.config(state="normal")
            print(f"[Capture] Loaded {len(loaded)} frame(s) from {self.capture_dir}")

    def capture_frame(self):
        if not self.running or self.current_corners is None or self.current_frame is None:
            return

        cw, ch = self.get_corner_dimensions()
        corners = self.current_corners.copy()
        frame = self.current_frame.copy()
        image_size = (frame.shape[1], frame.shape[0])

        self.capture_dir.mkdir(parents=True, exist_ok=True)
        stem = f"{self._next_capture_id():04d}"
        png_path = self.capture_dir / f"{stem}.png"
        npz_path = self.capture_dir / f"{stem}.npz"
        if not cv2.imwrite(str(png_path), frame):
            print(f"[Capture] Failed to write {png_path}")
            return
        np.savez(
            str(npz_path),
            corners=corners,
            board_w=np.int32(cw),
            board_h=np.int32(ch),
            image_w=np.int32(image_size[0]),
            image_h=np.int32(image_size[1]),
        )

        with self.lock:
            self.samples.append({
                "corners": corners,
                "board_w": cw,
                "board_h": ch,
                "image_size": image_size,
            })
            count = len(self.samples)

        self._refresh_sample_label()
        self.btn_calc.config(state="normal")
        print(f"[Capture] Frame #{count} saved to {png_path}")

    def calibrate_and_save(self):
        with self.lock:
            samples = list(self.samples)

        if len(samples) < 10:
            messagebox.showwarning(
                "Insufficient Data", 
                f"Please capture at least 10 frames (currently: {len(samples)})."
            )
            return

        sizes = {sample["image_size"] for sample in samples}
        if len(sizes) != 1:
            messagebox.showwarning(
                "Mixed image sizes",
                "Saved frames do not all have the same resolution.",
            )
            return

        img_size = samples[0]["image_size"]
        square_size_m = self._square_size_m()
        objpoints = []
        imgpoints = []
        for sample in samples:
            cw, ch = sample["board_w"], sample["board_h"]
            if len(sample["corners"]) != cw * ch:
                messagebox.showwarning(
                    "Board size mismatch",
                    "A saved frame does not match the checkerboard corner count.",
                )
                return
            objp = np.zeros((cw * ch, 3), np.float32)
            objp[:, :2] = np.mgrid[0:cw, 0:ch].T.reshape(-1, 2) * square_size_m
            objpoints.append(objp)
            imgpoints.append(sample["corners"])

        ret, K, dist, _, _ = cv2.calibrateCamera(
            objpoints, imgpoints, img_size, None, None
        )

        fx, fy = float(K[0, 0]), float(K[1, 1])
        cx, cy = float(K[0, 2]), float(K[1, 2])
        k1, k2, p1, p2 = float(dist[0][0]), float(dist[0][1]), float(dist[0][2]), float(dist[0][3])

        yaml_content = f"""%YAML:1.0

#--------------------------------------------------------------------------------------------
# Camera Parameters for ORB-SLAM3 (DJI Tello Drone)
#--------------------------------------------------------------------------------------------
File.version: "1.0"

Camera.type: "PinHole"

# Camera calibration and distortion parameters (OpenCV)
Camera1.fx: {fx:.6f}
Camera1.fy: {fy:.6f}
Camera1.cx: {cx:.6f}
Camera1.cy: {cy:.6f}

Camera1.k1: {k1:.6f}
Camera1.k2: {k2:.6f}
Camera1.p1: {p1:.6f}
Camera1.p2: {p2:.6f}

# Tello Camera resolution & framerate
Camera.width: {img_size[0]}
Camera.height: {img_size[1]}
Camera.fps: 30
Camera.RGB: 1

#--------------------------------------------------------------------------------------------
# ORB Parameters
#--------------------------------------------------------------------------------------------
ORBextractor.nFeatures: 1200
ORBextractor.scaleFactor: 1.2
ORBextractor.nLevels: 8
ORBextractor.iniThFAST: 20
ORBextractor.minThFAST: 7

#--------------------------------------------------------------------------------------------
# Viewer Parameters
#--------------------------------------------------------------------------------------------
Viewer.KeyFrameSize: 0.05
Viewer.KeyFrameLineWidth: 1.0
Viewer.GraphLineWidth: 0.9
Viewer.PointSize: 2.0
Viewer.CameraSize: 0.08
Viewer.CameraLineWidth: 3.0
Viewer.ViewpointX: 0.0
Viewer.ViewpointY: -0.7
Viewer.ViewpointZ: -1.8
Viewer.ViewpointF: 500.0
"""
        output_filename = "tello_orbslam3.yaml"
        with open(output_filename, "w") as f:
            f.write(yaml_content)

        messagebox.showinfo(
            "Calibration Complete", 
            f"Calibration finished successfully!\n\n"
            f"Reprojection Error (RMS): {ret:.4f}\n"
            f"Output file: {output_filename}"
        )

    def on_closing(self):
        self.running = False
        if self.tello:
            try:
                self.tello.streamoff()
                self.tello.end()
            except:
                pass
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = TelloCalibratorUI(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()