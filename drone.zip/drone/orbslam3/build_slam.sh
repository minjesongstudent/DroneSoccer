#!/bin/bash
# Builds Pangolin, ORB-SLAM3, and the headless worker after OpenCV is installed.
set -euo pipefail
ROOT="$HOME/orbslam3-build"
cd "$ROOT"

if [ ! -f "$ROOT/install/lib/libopencv_core.so" ]; then
  echo "OpenCV is not installed yet." >&2
  exit 1
fi

export CMAKE_PREFIX_PATH="$ROOT/install"
export CPLUS_INCLUDE_PATH="$ROOT/sysroot/usr/include${CPLUS_INCLUDE_PATH:+:$CPLUS_INCLUDE_PATH}"
export LIBRARY_PATH="$ROOT/sysroot/usr/lib/x86_64-linux-gnu:$ROOT/local/lib${LIBRARY_PATH:+:$LIBRARY_PATH}"
export LD_LIBRARY_PATH="$ROOT/install/lib:$ROOT/local/lib:$ROOT/sysroot/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"

if [ ! -f "$ROOT/install/include/eigen3/Eigen/Core" ]; then
  cmake -S eigen -B eigen/build -DCMAKE_INSTALL_PREFIX="$ROOT/install"
  cmake --install eigen/build
fi

if [ ! -f "$ROOT/install/lib/libpangolin.so" ]; then
  ln -sfn /usr/lib/x86_64-linux-gnu/libGL.so.1 "$ROOT/local/lib/libGL.so"
  ln -sfn /usr/lib/x86_64-linux-gnu/libGL.so.1 "$ROOT/local/lib/libOpenGL.so"
  ln -sfn /usr/lib/x86_64-linux-gnu/libGLX.so.0 "$ROOT/local/lib/libGLX.so"
  ln -sfn "$ROOT/sysroot/usr/lib/x86_64-linux-gnu/libGLEW.so.2.2.0" "$ROOT/local/lib/libGLEW.so"
  cmake -S Pangolin -B Pangolin/build \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_INSTALL_PREFIX="$ROOT/install" \
    -DCMAKE_PREFIX_PATH="$ROOT/install" \
    -DCMAKE_INCLUDE_PATH="$ROOT/sysroot/usr/include" \
    -DCMAKE_LIBRARY_PATH="$ROOT/local/lib:$ROOT/sysroot/usr/lib/x86_64-linux-gnu" \
    -DOPENGL_opengl_LIBRARY="$ROOT/local/lib/libOpenGL.so" \
    -DOPENGL_gl_LIBRARY="$ROOT/local/lib/libGL.so" \
    -DOPENGL_glx_LIBRARY="$ROOT/local/lib/libGLX.so" \
    -DGLEW_LIBRARY="$ROOT/local/lib/libGLEW.so" \
    -DGLEW_INCLUDE_DIR="$ROOT/sysroot/usr/include" \
    -DCMAKE_CXX_FLAGS="-include cstdint" \
    -DBUILD_EXAMPLES=OFF \
    -DBUILD_TESTS=OFF \
    -DBUILD_TOOLS=OFF
  cmake --build Pangolin/build -j 8
  cmake --install Pangolin/build
fi

cd "$ROOT/ORB_SLAM3"
if [ ! -f Vocabulary/ORBvoc.txt ]; then
  tar -xf Vocabulary/ORBvoc.txt.tar.gz -C Vocabulary
fi
if [ ! -f Thirdparty/DBoW2/lib/libDBoW2.so ]; then
  cmake -S Thirdparty/DBoW2 -B Thirdparty/DBoW2/build -DCMAKE_BUILD_TYPE=Release
  cmake --build Thirdparty/DBoW2/build -j 8
fi
if [ ! -f Thirdparty/g2o/lib/libg2o.so ]; then
  cmake -S Thirdparty/g2o -B Thirdparty/g2o/build -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$ROOT/install"
  cmake --build Thirdparty/g2o/build -j 8
fi
python3 - <<'PY'
from pathlib import Path
path = Path("CMakeLists.txt")
text = path.read_text()
marker = "# Build examples"
if marker in text:
    path.write_text(text.split(marker, 1)[0])
PY
if [ ! -f lib/libORB_SLAM3.so ]; then
  cmake -S . -B build \
    -DCMAKE_BUILD_TYPE=Release \
    -DCMAKE_PREFIX_PATH="$ROOT/install" \
    -DEigen3_DIR="$ROOT/install/share/eigen3/cmake" \
    -DOpenCV_DIR="$ROOT/install/lib/cmake/opencv4" \
    -DPangolin_DIR="$ROOT/install/lib/cmake/Pangolin" \
    -DCMAKE_INCLUDE_PATH="$ROOT/sysroot/usr/include" \
    -DCMAKE_LIBRARY_PATH="$ROOT/sysroot/usr/lib/x86_64-linux-gnu:$ROOT/local/lib" \
    -DCMAKE_SHARED_LINKER_FLAGS="-L$ROOT/local/lib -L$ROOT/sysroot/usr/lib/x86_64-linux-gnu" \
    -DCMAKE_EXE_LINKER_FLAGS="-L$ROOT/local/lib -L$ROOT/sysroot/usr/lib/x86_64-linux-gnu"
  cmake --build build -j 8
fi

g++ -O3 -std=c++14 \
  -I"$ROOT/ORB_SLAM3/include" \
  -I"$ROOT/ORB_SLAM3/include/CameraModels" \
  -I"$ROOT/ORB_SLAM3" \
  -I"$ROOT/ORB_SLAM3/Thirdparty/Sophus" \
  -I"$ROOT/install/include/eigen3" \
  -I"$ROOT/install/include" \
  -I"$ROOT/install/include/opencv4" \
  /mnt/d/codebymin/classes/drone/orbslam3/worker.cpp \
  -o "$ROOT/worker" \
  -L"$ROOT/ORB_SLAM3/lib" -lORB_SLAM3 \
  -L"$ROOT/install/lib" -lpangolin \
  -L"$ROOT/local/lib" -lGLEW -lGL -lGLX \
  -L"$ROOT/ORB_SLAM3/Thirdparty/DBoW2/lib" -lDBoW2 \
  -L"$ROOT/ORB_SLAM3/Thirdparty/g2o/lib" -lg2o \
  -L"$ROOT/install/lib" -lopencv_core -lopencv_imgproc -lopencv_features2d -lopencv_flann -lopencv_calib3d -lopencv_highgui \
  -L"$ROOT/local/lib" -lboost_serialization \
  -lcrypto -lpthread -ldl
echo "worker ready"
